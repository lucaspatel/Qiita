.. automodule:: biom.table
