# ----------------------------------------------------------------------------
# Copyright (c) 2013--, scikit-bio development team.
#
# Distributed under the terms of the Modified BSD License.
#
# The full license is in the file LICENSE.txt, distributed with this software.
# ----------------------------------------------------------------------------

from __future__ import annotations

import math
from functools import partial
from warnings import warn
from typing import TYPE_CHECKING

import numpy as np

from ._base import (
    _preprocess_input_sng,
    _run_monte_carlo_stats,
    _build_results,
    DistanceMatrix,
)
from ._cutils import permanova_f_stat_sW_cy, permanova_f_stat_sW_condensed_cy
from ._gpu import _mark_gpu_unavailable
from ._permanova_gpu import _numba_gpu_module_for, _run_permanova_gpu
from skbio.binaries import (
    permanova_available as _skbb_permanova_available,
    permanova as _skbb_permanova,
)
from skbio.util import get_rng
from skbio.util._decorator import params_aliased, array_api_doc
from skbio.util._array import ingest_array
from skbio._config import _resolve_engine

import array_api_compat as _aac

try:
    from numba import njit, prange

    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False

if TYPE_CHECKING:  # pragma: no cover
    from numpy.typing import ArrayLike
    import pandas as pd
    from skbio.util._typing import SeedLike


if NUMBA_AVAILABLE:

    @njit(parallel=True)
    def _permanova_f_stat_sW_nb(distance_matrix, group_sizes, grouping):
        """Compute s_W for full (non-condensed) distance matrix using Numba.

        Replaces the following natural Numba code, which triggers a parfor
        cycle bug in Numba 0.65.x when the scalar reduction variable is read
        inside the inner loop::

            @njit(parallel=True)
            def _permanova_f_stat_sW_nb(
                distance_matrix, group_sizes, grouping
            ):
                n = distance_matrix.shape[0]
                s_W = 0.0
                for row_idx in prange(n - 1):
                    group_idx = grouping[row_idx]
                    local_sum = 0.0
                    for col_idx in range(row_idx + 1, n):
                        if grouping[col_idx] == group_idx:
                            val = distance_matrix[row_idx, col_idx]
                            local_sum += val * val
                    s_W += local_sum / group_sizes[group_idx]
                return s_W

        Instead, each parallel iteration writes its row-pair contribution to
        a partials array and the final sum is performed sequentially. The
        loop also pairs row_idx with its mirror (n - row_idx - 2) so each
        prange iteration handles a comparable amount of work, matching the
        Cython implementation's load-balancing pattern.

        Parameters
        ----------
        distance_matrix : np.ndarray, shape (n, n)
            Full symmetric distance matrix.
        group_sizes : np.ndarray, shape (num_groups,)
            Number of objects in each group (precomputed via np.bincount).
        grouping : np.ndarray, shape (n,)
            Integer group label for each object (values 0 to num_groups - 1).

        Returns
        -------
        float
            The within-group sum of squares s_W.

        """
        n = distance_matrix.shape[0]
        n_half = n // 2
        partials = np.zeros(n_half, np.float64)

        for row_idx in prange(n_half):
            group_idx = grouping[row_idx]
            local_sum = 0.0
            for col_idx in range(row_idx + 1, n):
                if grouping[col_idx] == group_idx:
                    # promote to float64 before squaring to match the Cython
                    # ``double`` accumulator (matters for float32 input)
                    val = np.float64(distance_matrix[row_idx, col_idx])
                    local_sum += val * val

            group_sum = local_sum / group_sizes[group_idx]

            mirror_row = n - row_idx - 2
            if mirror_row != row_idx:
                group_idx = grouping[mirror_row]
                local_sum = 0.0
                for col_idx in range(mirror_row + 1, n):
                    if grouping[col_idx] == group_idx:
                        val = np.float64(distance_matrix[mirror_row, col_idx])
                        local_sum += val * val
                group_sum += local_sum / group_sizes[group_idx]

            partials[row_idx] = group_sum

        return partials.sum()

    @njit(parallel=True)
    def _permanova_f_stat_sW_condensed_nb(condensed_matrix, group_sizes, grouping):
        """Compute s_W for condensed distance matrix using Numba.

        Same as ``_permanova_f_stat_sW_nb`` but accepts ``condensed_matrix``
        in condensed form (1-D array of length ``n * (n - 1) // 2``) instead
        of the full 2-D matrix. Uses the standard condensed-index formula to
        map ``(row_idx, col_idx)`` pairs back to the 1-D array. The same
        Numba 0.65.x parfor cycle workaround applies (partials array + final
        sequential sum); see the full version for the equivalent natural
        Numba code.

        Parameters
        ----------
        condensed_matrix : np.ndarray, shape (k,)
            Condensed (upper triangle) distance matrix where
            k = n * (n - 1) // 2.
        group_sizes : np.ndarray, shape (num_groups,)
            Number of objects in each group.
        grouping : np.ndarray, shape (n,)
            Integer group label for each object.

        Returns
        -------
        float
            The within-group sum of squares s_W.

        """
        k = condensed_matrix.shape[0]
        n = int((1.0 + math.sqrt(1.0 + 8.0 * k)) / 2.0)
        n_half = n // 2
        partials = np.zeros(n_half, np.float64)

        for row_idx in prange(n_half):
            group_idx = grouping[row_idx]
            local_sum = 0.0
            for col_idx in range(row_idx + 1, n):
                if grouping[col_idx] == group_idx:
                    condensed_idx = (
                        row_idx * n + col_idx - ((row_idx + 2) * (row_idx + 1)) // 2
                    )
                    val = np.float64(condensed_matrix[condensed_idx])
                    local_sum += val * val

            group_sum = local_sum / group_sizes[group_idx]

            mirror_row = n - row_idx - 2
            if mirror_row != row_idx:
                group_idx = grouping[mirror_row]
                local_sum = 0.0
                for col_idx in range(mirror_row + 1, n):
                    if grouping[col_idx] == group_idx:
                        condensed_idx = (
                            mirror_row * n
                            + col_idx
                            - ((mirror_row + 2) * (mirror_row + 1)) // 2
                        )
                        val = condensed_matrix[condensed_idx]
                        local_sum += val * val
                group_sum += local_sum / group_sizes[group_idx]

            partials[row_idx] = group_sum

        return partials.sum()

    @njit(parallel=True)
    def _permanova_f_stat_sW_rowtile_nb(
        distance_matrix, groupings_T, inv_group_sizes, partials
    ):
        """Compute partial s_W for a chunk of permutations in one matrix pass.

        Parallelises over distance-matrix rows (each paired with its mirror row
        ``n - row - 2`` for load balance, as in ``_permanova_f_stat_sW_nb``)
        rather than over permutations. Each row is owned by one worker, so each
        distance is read from memory once per chunk and reused across all
        permutations of the chunk, instead of streaming the whole matrix once
        per permutation. The kernel is memory-bound, so this reuse -- not the
        arithmetic -- is what determines its speed; it mirrors the cache reuse
        of scikit-bio-binaries' ``pmn_f_stat_sW_cpu`` in
        ``permanova_dyn_impl.hpp``.

        The permutation loop is kept branchless (a uniform read-and-accumulate
        over the grouping windows, with no data-dependent control flow), and
        ``groupings_T`` is sample-major ``int32`` so each permutation's labels
        are read as a contiguous, low-bandwidth window.

        Parameters
        ----------
        distance_matrix : np.ndarray, shape (n, n)
            Full symmetric distance matrix.
        groupings_T : np.ndarray, shape (n, n_perm), int32
            Permuted groupings, sample-major (transposed) and C-contiguous.
        inv_group_sizes : np.ndarray, shape (num_groups,)
            Reciprocal group sizes (``1.0 / group_sizes``), precomputed so the
            hot loop multiplies instead of dividing.
        partials : np.ndarray, shape (n // 2, C) with C >= n_perm
            Reused scratch (allocated once by the caller). Each iteration zeros
            and fills the first ``n_perm`` entries of its own row ``partials[i]``
            with the s_W contribution of the mirror-pair it handles. The caller
            sums the first ``n_perm`` columns over axis 0 to obtain s_W per
            permutation.

        """
        n = distance_matrix.shape[0]
        n_perm = groupings_T.shape[1]
        n_half = n // 2

        # Each worker owns one row (and its mirror for load balance), so each
        # distance is read once per chunk and reused across all permutations.
        for row_idx in prange(n_half):
            # partials is reused across chunks, so zero this row's accumulator.
            local_sW = partials[row_idx]
            for p in range(n_perm):
                local_sW[p] = 0.0
            rsum = np.empty(n_perm, np.float64)

            for p in range(n_perm):
                rsum[p] = 0.0
            for col in range(row_idx + 1, n):
                # promote to float64 before squaring to match the Cython
                # ``double`` accumulator (matters for float32 input)
                val = np.float64(distance_matrix[row_idx, col])
                val2 = val * val
                # branchless: scale val2 by the 0/1 group-match instead of an
                # if, so the loop is a uniform read-accumulate over the grouping
                # window (no data-dependent control flow) -- val2 stays in a
                # register and is reused for every permutation
                for p in range(n_perm):
                    rsum[p] += val2 * np.float64(
                        groupings_T[col, p] == groupings_T[row_idx, p]
                    )
            for p in range(n_perm):
                local_sW[p] += rsum[p] * inv_group_sizes[groupings_T[row_idx, p]]

            mirror_row = n - row_idx - 2
            if mirror_row != row_idx:
                for p in range(n_perm):
                    rsum[p] = 0.0
                for col in range(mirror_row + 1, n):
                    val = np.float64(distance_matrix[mirror_row, col])
                    val2 = val * val
                    for p in range(n_perm):
                        rsum[p] += val2 * np.float64(
                            groupings_T[col, p] == groupings_T[mirror_row, p]
                        )
                for p in range(n_perm):
                    local_sW[p] += rsum[p] * inv_group_sizes[groupings_T[mirror_row, p]]

    @njit(inline="always")
    def _condensed_row_base(row, n):
        """Flat offset such that condensed_matrix[base + col] is (row, col).

        Only valid for col > row. Numba inlines this at both call sites in
        ``_permanova_f_stat_sW_rowtile_condensed_nb`` below, so factoring it
        out costs nothing at runtime.
        """
        return row * n - ((row + 2) * (row + 1)) // 2

    @njit(parallel=True)
    def _permanova_f_stat_sW_rowtile_condensed_nb(
        condensed_matrix, groupings_T, inv_group_sizes, partials
    ):
        """Compute partial s_W for a chunk of permutations from condensed data.

        Same single-pass, row-parallel strategy as
        ``_permanova_f_stat_sW_rowtile_nb`` but reads the distance matrix in
        condensed (upper-triangle, 1-D) form. Each ``(row, col)`` pair with
        ``col > row`` maps to the condensed index
        ``row * n + col - ((row + 2) * (row + 1)) // 2`` (the same mapping
        used by ``_permanova_f_stat_sW_condensed_nb``). Because the inner
        loop only visits ``col > row`` the ``vrow < vcol`` branch used by the
        condensed Mantel kernel is unnecessary here.

        Parameters
        ----------
        condensed_matrix : np.ndarray, shape (k,)
            Condensed (upper triangle) distance matrix,
            k = n * (n - 1) // 2.
        groupings_T : np.ndarray, shape (n, n_perm), int32
            Permuted groupings, sample-major (transposed) and C-contiguous.
        inv_group_sizes : np.ndarray, shape (num_groups,)
            Reciprocal group sizes (``1.0 / group_sizes``).
        partials : np.ndarray, shape (n // 2, C) with C >= n_perm
            Reused scratch; each iteration fills the first ``n_perm`` entries
            of its own row (no separate zero pass needed -- the first write
            per row is an assignment, not an accumulate).

        """
        k = condensed_matrix.shape[0]
        n = int((1.0 + math.sqrt(1.0 + 8.0 * k)) / 2.0)
        n_perm = groupings_T.shape[1]
        n_half = n // 2

        for row_idx in prange(n_half):
            local_sW = partials[row_idx]
            rsum = np.empty(n_perm, np.float64)

            for p in range(n_perm):
                rsum[p] = 0.0
            base = _condensed_row_base(row_idx, n)
            for col in range(row_idx + 1, n):
                val = np.float64(condensed_matrix[base + col])
                val2 = val * val
                for p in range(n_perm):
                    rsum[p] += val2 * np.float64(
                        groupings_T[col, p] == groupings_T[row_idx, p]
                    )
            for p in range(n_perm):
                local_sW[p] = rsum[p] * inv_group_sizes[groupings_T[row_idx, p]]

            mirror_row = n - row_idx - 2
            if mirror_row != row_idx:
                for p in range(n_perm):
                    rsum[p] = 0.0
                mbase = _condensed_row_base(mirror_row, n)
                for col in range(mirror_row + 1, n):
                    val = np.float64(condensed_matrix[mbase + col])
                    val2 = val * val
                    for p in range(n_perm):
                        rsum[p] += val2 * np.float64(
                            groupings_T[col, p] == groupings_T[mirror_row, p]
                        )
                for p in range(n_perm):
                    local_sW[p] += rsum[p] * inv_group_sizes[groupings_T[mirror_row, p]]

    def _run_permanova_rowtile_nb(
        distmat, grouping, group_sizes, s_T, num_groups, sample_size, permutations, seed
    ):
        """Run PERMANOVA with the row-tile (single matrix pass) strategy.

        Generates the ``permutations + 1`` groupings in fixed-size chunks and,
        for each chunk, computes s_W via ``_permanova_f_stat_sW_rowtile_nb``,
        which reads the distance matrix only once per chunk (parallelism is over
        matrix rows, not permutations).  This is the cross-thread cache-reuse
        path of scikit-bio-binaries; it is markedly faster than the
        per-permutation kernel on large matrices, which are memory-bound.

        Groupings are transposed to sample-major ``int32`` once per chunk so the
        kernel's permutation loop reads contiguous, low-bandwidth windows; the
        transpose costs a small fraction of the matrix scan.  Permutations are
        drawn in the same RNG order as the sequential Monte Carlo path, so
        p-values are unchanged.

        Parameters
        ----------
        distmat : DistanceMatrix
            Full or condensed distance matrix; dispatches to the matching
            row-tile kernel based on ``distmat._flags["CONDENSED"]``.
        grouping : np.ndarray, shape (n,)
            Integer group labels (0-indexed).
        group_sizes : np.ndarray, shape (num_groups,)
            Number of objects per group.
        s_T : float
            Total sum of squares, precomputed by the caller.
        num_groups : int
            Number of distinct groups.
        sample_size : int
            Number of objects (n).
        permutations : int
            Number of Monte Carlo permutations.
        seed : int, Generator, or None
            Random seed passed to ``get_rng``.

        Returns
        -------
        stat : float
            Observed pseudo-F statistic.
        p_value : float
            Permutation p-value.

        """
        if permutations < 0:
            raise ValueError(
                "Number of permutations must be greater than or equal to zero."
            )

        rng = get_rng(seed)
        n_total = permutations + 1
        out_sW = np.empty(n_total, np.float64)
        inv_group_sizes = 1.0 / group_sizes.astype(np.float64)
        n_half = sample_size // 2
        rowtile_kernel = (
            _permanova_f_stat_sW_rowtile_condensed_nb
            if distmat._flags["CONDENSED"]
            else _permanova_f_stat_sW_rowtile_nb
        )

        # CHUNK is the number of permutations processed per pass over the
        # matrix. It is not a parallelism knob (the kernel parallelises over
        # matrix rows); it sizes each worker's private working set -- its rsum
        # accumulator and the grouping windows it reads -- so it is a fixed
        # constant chosen to keep that set in L1, not scaled with the thread
        # count. It also bounds peak memory to (CHUNK x n) regardless of the
        # permutation count.
        CHUNK = 256
        width = min(CHUNK, n_total)
        # Permutation-major int32 buffer; rng.permutation fills a row, so the
        # writes are sequential. Allocated once and reused across chunks.
        buf = np.empty((width, sample_size), dtype=np.int32)
        # Kernel scratch, allocated once and reused; max width is CHUNK. The
        # full-matrix kernel zeros each row before accumulating into it, while
        # the condensed kernel's first write per row is a plain assignment, so
        # neither kernel depends on stale contents left over from a prior chunk.
        partials = np.empty((n_half, width), np.float64)
        for start in range(0, n_total, CHUNK):
            end = min(start + CHUNK, n_total)
            chunk_size = end - start
            for i in range(start, end):
                if i == 0:
                    buf[0] = grouping
                else:
                    buf[i - start] = rng.permutation(grouping)

            # Transpose to sample-major so the kernel reads each permutation's
            # labels as a contiguous window; buf is permutation-major and buf.T
            # is a non-contiguous view, so this materialises the C-contiguous
            # copy the kernel needs.
            groupings_T = np.ascontiguousarray(buf[:chunk_size].T)
            rowtile_kernel(distmat.data, groupings_T, inv_group_sizes, partials)
            # sum each row-pair's partial contribution into s_W per permutation
            out_sW[start:end] = partials[:, :chunk_size].sum(axis=0)

        s_A = s_T - out_sW
        f_stats = (s_A / (num_groups - 1)) / (out_sW / (sample_size - num_groups))
        stat = f_stats[0]
        if permutations == 0:
            return stat, np.nan
        p_value = (1.0 + np.sum(f_stats[1:] >= stat)) / (1.0 + permutations)
        return stat, p_value


@params_aliased([("distmat", "distance_matrix", "0.7.0", False)])
@array_api_doc(backends=["numpy", "jax", "torch", "cupy"])
def permanova(
    distmat: DistanceMatrix,
    grouping: pd.DataFrame | ArrayLike,
    column: str | None = None,
    permutations: int = 999,
    seed: SeedLike | None = None,
    engine: str | None = None,
) -> pd.Series:
    r"""Test for significant differences between groups using PERMANOVA.

    Permutational Multivariate Analysis of Variance (PERMANOVA) is a non-parametric
    method that tests whether two or more groups of objects (e.g., samples) are
    significantly different based on a categorical factor. It is conceptually
    similar to ANOVA except that it operates on distances between objects via a
    distance matrix, which allows for multivariate analysis. Unlike classical
    Multivariate Analysis of Variance (MANOVA), PERMANOVA makes no assumptions
    about the distribution of the underlying data. As such, rather than computing
    a true `F` statistic based in known distributions of variables, it computes a
    pseudo-`F` statistic whose significance can be assessed by a permutation test.

    The pseudo-`F` statistic is the ratio of between-group variance to within-group
    variance, defined in [1]_ analogously to the `F` statistic in ANOVA:

    .. math::
        F = \frac{{SS}_{between}/(g - 1)}{{SS}_{within}/(n - g)}

    It is computed from the sums of squares :math:`{SS}_{between}` and
    :math:`{SS}_{within}` divided by their corresponding degrees of freedom, where
    :math:`n` is the number of distinct objects and :math:`g` is the number of groups.

    Statistical significance is assessed via a permutation test. Objects in the distance
    matrix are assigned to groups (`grouping`) based on a categorical factor. This
    assignment of groups is permuted a number of times (controlled via `permutations`),
    and a pseudo-`F` statistic is computed for each permutation. Under the null
    hypothesis that the groupings of objects have no effect on the distribution of
    the underlying data, the pseudo-`F` statistics of these permutations should be
    identically distributed for a given distance matrix. The probability of a given
    pseudo-`F` statistic being at least as extreme as an observed one is then the
    proportion of permuted pseudo-`F` statistics (:math:`F^{\pi}`) that are greater
    than or equal to the observed (unpermuted) one (:math:`F`):

    .. math::
        p = \frac{1 + \text{no. of } F^{\pi} \geq F}{1 + \text{no. of permutations}}

    Parameters
    ----------
    distmat : DistanceMatrix
        Distance matrix containing distances between samples.
    grouping : 1-D array_like or pandas.DataFrame
        Vector indicating the assignment of samples to groups. These could be strings
        or integers denoting which group a sample belongs to. If 1-D array-like, it
        must be the same length and in the same order as the samples in ``distmat``. If
        a DataFrame, the column specified by ``column`` will be used as the grouping
        vector. The DataFrame must be indexed by the IDs in ``distmat``, but the order
        of IDs between ``distmat`` and the DataFrame need not be the same. All IDs in
        the distance matrix must be present in the DataFrame. Extra IDs in the DataFrame
        are allowed and ignored in the calculation.
    column : str, optional
        Column name to use as the grouping vector if ``grouping`` is a DataFrame. Must
        be provided if ``grouping`` is a DataFrame. Cannot be provided if ``grouping``
        is 1-D array-like.
    permutations : int, optional
        Number of permutations to use when assessing statistical significance. Must be
        greater than or equal to zero. If zero, statistical significance calculations
        will be skipped and the *p*-value will be NaN.
    seed : int, Generator or RandomState, optional
        A user-provided random seed or random generator instance. See :func:`details
        <skbio.util.get_rng>`.

        .. versionadded:: 0.6.3
    engine : {'cython', 'numba', 'fast'}, optional
        Compute engine for the PERMANOVA statistic and permutation test. If None
        (default), use the global ``compute_engine`` setting. 'fast' selects Numba if
        installed, otherwise Cython. See :ref:`compute_engines` for details.

        .. versionadded:: 0.7.4

    Returns
    -------
    pandas.Series
        Results of the statistical test, including ``test statistic`` and
        ``p-value``.

    See Also
    --------
    anosim
    statsmodels.multivariate.manova.MANOVA
    scipy.stats.permutation_test

    Notes
    -----
    See [1]_ for the original method reference, as well as ``vegan::adonis``,
    available in R's vegan package [2]_.

    The precision of the `p`-value is dependent on the number of permutations. The
    default precision is :math:`0.001=1/(1+999)` from the default value
    ``permutations=999``. The unpermuted grouping always contributes the first
    permutation to the numerator and denominator of the `p`-value, so 1 is added
    to both. This circumvents the risk of the probability being zero by chance
    even when it is nonzero. It is suggested in [1]_ that at least 1000
    permutations should be performed for a confidence level of 0.05, and
    5000 permutations should be performed for a confidence level of 0.01. The
    `p`-value will be ``np.nan`` if ``permutations`` is zero.

    A related statistic reported by some implementations (such as
    ``vegan::adonis``) is the :math:`R^2` value, which describes the proportion
    of variance in the data explained by the grouping:

    .. math::
        R^2 = \frac{{SS}_{between}}{{SS}_{total}}

    This is not currently computed by this function, but it may be derived from the
    outputs using the following formula:

    .. math::
        R^2 = \frac{1}{1 + \frac{n - g}{(g - 1)F}}

    where :math:`F` is the pseudo-`F` statistic, :math:`n` is the number of
    objects, and :math:`g` is the number of groups.

    **Performance**

    This function uses parallel computation for improved performance. See the
    :ref:`parallelization guide <parallelization>` for information on controlling the
    number of threads used. See also :ref:`binary_acceleration` for another option of
    acceleration.

    On a GPU-resident distance matrix with ``engine='numba'``, a fused GPU kernel
    runs on CuPy or PyTorch matrices, on both CUDA and ROCm devices. The exception
    is ROCm PyTorch on stacks where a Numba HIP kernel cannot be compiled after
    ROCm PyTorch has been imported in the same process; those matrices fall back
    to the array-API path, which runs on the device regardless. The result is
    identical across all paths.

    With ``engine='numba'``, GPU buffers must belong to the default device. On a
    system with several devices, the default must be changed to match the buffer
    ownership before this function is invoked, through
    ``numba.cuda.select_device`` on CUDA or ``numba.hip.select_device`` on ROCm.
    A mismatch is not reported when the kernel is launched, and on ROCm it has
    been observed to leave the GPU context unusable for the rest of the process.
    The array-API path, taken when ``engine='numba'`` is not requested, honors
    whichever device the input is on.

    References
    ----------
    .. [1] Anderson, Marti J. "A new method for non-parametric multivariate
       analysis of variance." Austral Ecology 26.1 (2001): 32-46.

    .. [2] http://cran.r-project.org/web/packages/vegan/index.html

    Examples
    --------
    See :mod:`skbio.stats.distance.anosim` for usage examples (both functions
    provide similar interfaces).

    """
    if not isinstance(distmat, DistanceMatrix):
        raise TypeError("Input must be a DistanceMatrix.")

    engine = _resolve_engine(
        engine,
        ("cython", "numba"),
        fast="numba" if NUMBA_AVAILABLE else "cython",
    )

    # A DistanceMatrix backed by a non-NumPy (e.g. GPU-resident) buffer: with
    # engine="numba" and a matching Numba GPU backend it runs the fused GPU
    # kernel on the device-resident matrix; otherwise it takes the backend-
    # agnostic xp path. A NumPy-backed DM keeps the Cython/Numba engine path.
    if not _aac.is_numpy_array(distmat.data):
        gpu = _numba_gpu_module_for(distmat.data) if engine == "numba" else None
        if gpu is not None:
            try:
                return _run_permanova_gpu(
                    gpu,
                    distmat.data,
                    grouping,
                    column,
                    permutations,
                    seed,
                    ids=distmat.ids,
                )
            except Exception:
                # The fused kernel could not build/run on this stack (e.g. a
                # numba-hip build that fails to compile); record it and fall
                # back to the array-API path, which is correct on any backend.
                _mark_gpu_unavailable(distmat.data)
        return _permanova_array_api(
            distmat.data, grouping, column, permutations, seed, ids=distmat.ids
        )

    sample_size = distmat.shape[0]

    num_groups, grouping = _preprocess_input_sng(
        distmat.ids, sample_size, grouping, column
    )

    # When "numba" is requested, skip the scikit-bio-binaries path (the
    # Cython-equivalent), matching the engine selection for the compute below.
    if engine != "numba" and _skbb_permanova_available(
        distmat, grouping, permutations, seed
    ):  # pragma: no cover
        # unlikely to throw here, but just in case
        try:
            stat, p_value = _skbb_permanova(distmat, grouping, permutations, seed)
            return _build_results(
                "PERMANOVA",
                "pseudo-F",
                sample_size,
                num_groups,
                stat,
                p_value,
                permutations,
            )
        except Exception as e:
            warn(
                "Attempted to use binaries.permanova but failed, "
                "using regular logic instead.",
                RuntimeWarning,
            )
    # if we got here, we could not use skbb
    # Calculate number of objects in each group.
    group_sizes = np.bincount(grouping)
    # accumulate in float64: for a float32 matrix s_T and s_W nearly cancel in
    # the pseudo-F, so a float32 sum here loses accuracy in the s_A = s_T - s_W step
    s_T = (distmat.data**2).sum(dtype=np.float64) / sample_size
    if not distmat._flags["CONDENSED"]:
        # we are going over the whole matrix, instead of just upper triangle
        # so cut in half
        s_T /= 2.0

    if engine == "numba":
        stat, p_value = _run_permanova_rowtile_nb(
            distmat,
            grouping,
            group_sizes,
            s_T,
            num_groups,
            sample_size,
            permutations,
            seed,
        )
    else:
        test_stat_function = partial(
            _compute_f_stat, sample_size, num_groups, distmat, group_sizes, s_T
        )
        stat, p_value = _run_monte_carlo_stats(
            test_stat_function, grouping, permutations, seed
        )

    return _build_results(
        "PERMANOVA", "pseudo-F", sample_size, num_groups, stat, p_value, permutations
    )


def _compute_f_stat(
    sample_size, num_groups, distance_matrix, group_sizes, s_T, grouping
):
    """Compute PERMANOVA pseudo-F statistic.

    Only used for ``engine == "cython"``: ``permanova()`` routes every
    ``engine == "numba"`` call through the row-tile path
    (``_run_permanova_rowtile_nb``) instead, for both full and condensed
    matrices.
    """
    # Calculate s_W for each group, accounting for different group sizes.
    if distance_matrix._flags["CONDENSED"]:
        s_W = permanova_f_stat_sW_condensed_cy(
            distance_matrix.data, group_sizes, grouping
        )
    else:
        s_W = permanova_f_stat_sW_cy(distance_matrix.data, group_sizes, grouping)

    s_A = s_T - s_W
    return (s_A / (num_groups - 1)) / (s_W / (sample_size - num_groups))


def _permanova_sW_xp(xp, dm, grouping, inv_group_sizes):
    """Within-group sum of squares s_W for a full distance matrix, in ``xp``.

    Backend-agnostic equivalent of ``permanova_f_stat_sW_cy`` for the
    non-condensed (full 2-D) case: sum over upper-triangle pairs ``i < j`` in
    the same group of ``d[i, j] ** 2`` divided by the group size of row ``i``.
    """
    n = dm.shape[0]
    idx = xp.arange(n, device=dm.device)
    upper = idx[:, None] < idx[None, :]
    same = grouping[:, None] == grouping[None, :]
    mask = xp.astype(upper & same, dm.dtype)
    row_w = xp.take(inv_group_sizes, grouping)
    return xp.sum(dm * dm * mask * row_w[:, None])


def _permanova_array_api(distmat, grouping, column, permutations, seed, ids=None):
    """PERMANOVA on an array-API (e.g. GPU-resident) full distance matrix.

    Mirrors the DistanceMatrix path but computes the pseudo-F statistic with
    the ``xp`` namespace so the distance matrix stays on its device. ``ids``
    align a DataFrame/Series grouping to the matrix rows. Permutations reuse the
    shared Monte-Carlo driver so the p-value matches the NumPy path exactly.
    """
    xp, dm = ingest_array(distmat)
    sample_size = dm.shape[0]

    num_groups, grouping = _preprocess_input_sng(ids, sample_size, grouping, column)

    group_sizes = np.bincount(grouping)
    inv_group_sizes = xp.asarray(1.0 / group_sizes, dtype=dm.dtype, device=dm.device)
    # full 2-D matrix (array-API input is never condensed); halve to count each
    # unordered pair once, matching the DistanceMatrix full-matrix path.
    s_T = xp.sum(dm * dm, dtype=xp.float64) / sample_size / 2.0

    def _test_stat(grp):
        grp = xp.asarray(grp, device=dm.device)
        s_W = _permanova_sW_xp(xp, dm, grp, inv_group_sizes)
        s_A = s_T - s_W
        return float((s_A / (num_groups - 1)) / (s_W / (sample_size - num_groups)))

    stat, p_value = _run_monte_carlo_stats(_test_stat, grouping, permutations, seed)
    return _build_results(
        "PERMANOVA", "pseudo-F", sample_size, num_groups, stat, p_value, permutations
    )
