# ----------------------------------------------------------------------------
# Copyright (c) 2013--, scikit-bio development team.
#
# Distributed under the terms of the Modified BSD License.
#
# The full license is in the file LICENSE.txt, distributed with this software.
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# This implementation of ANCOM-BC is based on an analysis of the source code
# of the R package ANCOMBC:
# - https://github.com/FrederickHuangLin/ANCOMBC
#
# Which is licensed under Artistic-2.0:
# - https://www.bioconductor.org/packages/release/bioc/html/ANCOMBC.html
#
# We thank Dr. Huang Lin (@FrederickHuangLin) for his helpful advice.
# ----------------------------------------------------------------------------

from __future__ import annotations

from typing import TYPE_CHECKING
from itertools import combinations

import numpy as np
import pandas as pd
from scipy.stats import norm, chi2, f, t
from scipy.optimize import minimize

from skbio.util import get_rng
from skbio.table._tabular import _ingest_table, _aggregate_features
from ._base import _check_composition
from ._utils import _check_metadata, _build_dmatrix, _adjust_pvalues

if TYPE_CHECKING:  # pragma: no cover
    from skbio.util._typing import SeedLike


def ancombc(
    table,
    metadata,
    formula,
    grouping=None,
    max_iter=100,
    tol=1e-5,
    alpha=0.05,
    p_adjust="holm",
):
    r"""Perform differential abundance test using ANCOM-BC.

    Analysis of compositions of microbiomes with bias correction (ANCOM-BC) [1]_ is a
    differential abundance testing method featuring the estimation and correction for
    the bias of differential sampling fractions.

    .. versionadded:: 0.7.1

    .. versionchanged:: 0.7.4
        Improved computational efficiency.

    Parameters
    ----------
    table : table_like of shape (n_samples, n_features)
        A matrix containing strictly positive count or proportional abundance data of
        the samples.
    metadata : pd.DataFrame or 2-D array_like
        Metadata of the samples. Rows correspond to samples and columns correspond
        to covariates (attributes). Must be a pandas DataFrame or convertible to a
        pandas DataFrame.
    formula : str or generic Formula object
        Formula defining the model using factors included in the metadata columns.
        Refer to `Patsy's documentation
        <https://patsy.readthedocs.io/en/latest/formulas.html>`_ on how to specify
        a formula.
    grouping : str, optional
        Metadata column defining sample groups for post-hoc analyses. Must be a term
        in ``formula`` and contain at least three groups. Other terms are treated as
        adjustment covariates. It has no impact on the main result. If None (default),
        post-hoc analyses will be unavailable.
    max_iter : int, optional
        Maximum number of iterations for the bias estimation process. Default is 100.
    tol : float, optional
        Absolute convergence tolerance for the bias estimation process. Default is
        1e-5.
    alpha : float, optional
        Significance level for the statistical tests. Must be in the range of (0, 1).
        Default is 0.05.
    p_adjust : str, optional
        Method to correct *p*-values for multiple comparisons. Options are: Bonferroni
        ("bonf"/"bonferroni"), Holm-Bonferroni ("holm"/"holm-bonferroni", default),
        Benjamini-Hochberg ("bh"/"benjamini-hochberg"), and Benjamini-Yekutieli
        ("by"/"benjamini-yekutieli"), or any method supported by statsmodels'
        :func:`~statsmodels.stats.multitest.multipletests` function. Case-insensitive.
        If None, no correction will be performed.

    Returns
    -------
    :class:`ANCOMBCResult`
        Result object with primary results and post-hoc analysis methods.

    .. versionchanged:: 0.7.4
        Global test is now deferred as a post-hoc analysis. See
        :meth:`~ANCOMBCResult.global_test`. "Log2(FC)" has been renamed as "Log(FC)"
        for accuracy.

    See Also
    --------
    ancombc2
    struc_zero

    Notes
    -----
    This function is a Python re-implementation of the ANCOM-BC method [1]_, which was
    originally implemented in the R package ``ANCOMBC``. This function provides an
    efficient and scalable algorithm, with a simple interface consistent with other
    scikit-bio components. The output of this function should match that of the R
    package.

    Comparing with the R command ``ancombc``, this function defers the flexibility of
    data preprocessing to the user. Most importantly, if the input table contains zero
    values (which is common), one needs to remove them by, e.g., adding a pseudocount
    of 1 (``pseudo=1`` in the R command's parameters) (assuming ``table`` is a pandas
    DataFrame):

    .. code-block:: python

       table += 1

    See also :func:`multi_replace` for additional information on zero handling.

    Some other pre-processing options provided by the R command can be performed with:

    To aggregate data at a given taxonomic level (``tax_level="Family"``):

    .. code-block:: python

       table = table.T.groupby(feature_to_family_dict).sum().T

    To discard features with prevalence < 10% among samples (``prv_cut=0.1``):

    .. code-block:: python

       table = table.loc[:, (table > 0).mean() >= 0.1]

    To discard samples with a total abundance < 1 million (``lib_cut=1e6``):

    .. code-block:: python

       table = table.loc[table.sum(axis=1) >= 1e6]

    Categorical columns in metadata are sorted alphabetically, and the reference level
    for each column is automatically set to be the first category. If this behavior is
    not intended, you will need to change the order manually, like:

    .. code-block:: python

       metadata['bmi'] = pd.Categorical(
           metadata['bmi'], categories=['lean', 'overweight', 'obese'], ordered=True)

    References
    ----------
    .. [1] Lin, H. and Peddada, S.D., 2020. Analysis of compositions of microbiomes
       with bias correction. Nature Communications, 11(1), p.3514.

    Examples
    --------
    >>> from skbio.stats.composition import ancombc
    >>> import pandas as pd

    **A basic example**

    Let's create a data table with six samples and seven features (e.g., these may be
    microbial taxa):

    >>> samples = ['S1', 'S2', 'S3', 'S4', 'S5', 'S6']
    >>> features = ['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7']
    >>> table = pd.DataFrame(
    ...     [[ 2,  0,  4,  7,  0,  0,  1],
    ...      [ 1,  1,  0,  6,  5,  1, 10],
    ...      [ 3,  0,  2,  9,  6,  0,  1],
    ...      [ 0, 12,  1,  2,  0,  3,  2],
    ...      [ 2,  2, 37,  0,  0,  7,  3],
    ...      [10,  1,  0,  0,  4,  4,  3]],
    ...     index=samples, columns=features)

    Then create a sampling grouping vector. In this example, there is a "healthy" group
    and a "sick" group.

    >>> grouping = ['healthy', 'healthy', 'healthy', 'sick', 'sick', 'sick']
    >>> metadata = pd.Series(grouping, index=samples, name='status').to_frame()

    Now run ``ancombc`` to determine if there are any features that are significantly
    different in abundance between the healthy and the sick groups. Note that a
    pseudocount of 1 is manually added to the table to remove zero values.

    >>> result = ancombc(table + 1, metadata, formula='status').result
    >>> result.round(3)
                              Log(FC)     SE      W  pvalue  qvalue  Signif
    FeatureID Covariate
    F1        Intercept         -0.045  0.218 -0.207   0.836   1.000   False
              status[T.sick]     0.126  0.589  0.214   0.831   1.000   False
    F2        Intercept         -0.873  0.137 -6.381   0.000   0.000    True
              status[T.sick]     1.241  0.538  2.307   0.021   0.105   False
    F3        Intercept         -0.202  0.475 -0.425   0.671   1.000   False
              status[T.sick]     0.561  0.964  0.582   0.561   1.000   False
    F4        Intercept          1.005  0.136  7.399   0.000   0.000    True
              status[T.sick]    -1.723  0.392 -4.399   0.000   0.000    True
    F5        Intercept          0.141  0.422  0.335   0.738   1.000   False
              status[T.sick]    -0.690  0.625 -1.104   0.270   1.000   False
    F6        Intercept         -0.873  0.137 -6.381   0.000   0.000    True
              status[T.sick]     1.480  0.160  9.255   0.000   0.000    True
    F7        Intercept          0.157  0.401  0.391   0.695   1.000   False
              status[T.sick]     0.049  0.405  0.121   0.904   1.000   False

    The covariate "status[T.sick]" stands for the effect of the "sick" group relative
    to the reference group, "healthy" (the first group in alphabetical order is
    automatically selected as the reference group). "Log(FC)" represents the
    bias-corrected fold change on the natural-log scale (positive/negative: more/less
    abundant in "sick" than in "healthy", respectively). A "True" in the "Signif"
    column indicates a significantly differentially abundant feature-covariate pair.
    This example shows that two features differ by healthy/sick status.

    >>> result.query('Covariate != "Intercept" & Signif == True').round(3)
                              Log(FC)     SE      W  pvalue  qvalue  Signif
    FeatureID Covariate
    F4        status[T.sick]    -1.723  0.392 -4.399     0.0     0.0    True
    F6        status[T.sick]     1.480  0.160  9.255     0.0     0.0    True

    **An advanced example**

    Now we will create a complex dataset with 15 samples grouped into three disease
    status: "mild", "moderate" and "severe", plus age as a confounder. Our goal is
    to identify features that are differentially abundant between disease status.

    >>> samples = [f'S{i}' for i in range(1, 16)]
    >>> features = [f'F{i}' for i in range(1, 9)]
    >>> data = [[ 2,  0,  7,  0,  0,  2,  3,  2],
    ...         [ 0,  2,  0,  1,  1,  2,  0,  0],
    ...         [ 3,  1,  0,  9,  0,  1,  1,  0],
    ...         [ 2,  0,  1,  8,  1,  0, 11, 46],
    ...         [ 1,  0,  1,  1,  0,  0,  2,  2],
    ...         [ 0,  3, 22,  1,  1,  1,  3,  0],
    ...         [ 1,  7, 16,  1,  0,  0,  2,  2],
    ...         [ 0,  5,  6,  1,  2,  1,  0,  1],
    ...         [ 1,  7,  0,  2,  1,  0,  3,  2],
    ...         [ 0,  6,  4,  2,  0,  2,  2,  1],
    ...         [ 3, 13,  7,  0,  0,  0,  3,  9],
    ...         [ 1,  8,  5,  1,  0,  0,  0,  0],
    ...         [ 0,  5, 14,  1,  0,  1,  0,  1],
    ...         [ 5, 26,  3,  2,  0,  3,  1,  3],
    ...         [ 0, 18,  7,  0,  0,  3,  1,  0]]
    >>> table = pd.DataFrame(data, index=samples, columns=features)
    >>> status = ['mild'] * 5 + ['moderate'] * 5 + ['severe'] * 5
    >>> age = [39, 19, 20, 31, 15, 37, 27, 47, 26, 23, 39, 48, 46, 33, 36]
    >>> metadata = pd.DataFrame({'status': status, 'age': age}, index=samples)

    Run ``ancombc``. This time, we specify two factors: "status" and "age" in the
    formula, such that the function will test the individual effects of each factor
    while controlling for the other.

    >>> res = ancombc(
    ...     table + 1, metadata, formula='status + age', grouping='status')
    >>> res_main = res.result
    >>> res_main.round(3)
                                  Log(FC)     SE      W  pvalue  qvalue  Signif
    FeatureID Covariate
    F1        Intercept             -0.006  0.346 -0.016   0.987   1.000   False
              status[T.moderate]    -0.337  0.245 -1.376   0.169   1.000   False
              status[T.severe]       0.278  0.350  0.792   0.428   1.000   False
              age                    0.001  0.011  0.117   0.907   1.000   False
    F2        Intercept              0.072  0.446  0.160   0.873   1.000   False
              status[T.moderate]     1.906  0.259  7.371   0.000   0.000    True
              status[T.severe]       2.935  0.304  9.649   0.000   0.000    True
              age                   -0.022  0.013 -1.697   0.090   0.538   False
    F3        Intercept             -1.690  0.570 -2.967   0.003   0.021    True
              status[T.moderate]     1.010  0.578  1.747   0.081   0.565   False
              status[T.severe]       0.717  0.517  1.388   0.165   1.000   False
              age                    0.063  0.022  2.871   0.004   0.033    True
    F4        Intercept              0.439  0.483  0.910   0.363   1.000   False
              status[T.moderate]    -0.046  0.405 -0.113   0.910   1.000   False
              status[T.severe]      -0.244  0.536 -0.455   0.649   1.000   False
              age                   -0.004  0.019 -0.199   0.842   1.000   False
    F5        Intercept             -1.227  0.393 -3.125   0.002   0.014    True
              status[T.moderate]     0.274  0.293  0.934   0.350   1.000   False
              status[T.severe]      -0.323  0.320 -1.011   0.312   1.000   False
              age                    0.027  0.014  2.001   0.045   0.318   False
    F6        Intercept             -0.439  0.440 -0.999   0.318   1.000   False
              status[T.moderate]     0.114  0.432  0.264   0.792   1.000   False
              status[T.severe]       0.375  0.544  0.691   0.490   1.000   False
              age                    0.008  0.016  0.464   0.643   1.000   False
    F7        Intercept              0.201  0.472  0.426   0.670   1.000   False
              status[T.moderate]     0.082  0.302  0.270   0.787   1.000   False
              status[T.severe]      -0.264  0.401 -0.658   0.510   1.000   False
              age                    0.004  0.016  0.256   0.798   1.000   False
    F8        Intercept             -0.168  0.526 -0.319   0.750   1.000   False
              status[T.moderate]    -0.402  0.584 -0.688   0.491   1.000   False
              status[T.severe]      -0.299  0.728 -0.411   0.681   1.000   False
              age                    0.022  0.018  1.222   0.222   1.000   False

    We found that feature "F2" is significantly differentially (more) abundant in
    "moderate" and "severe" groups compared with "mild", which serves as the reference
    group. Additionally, feature "F3" is separately correlated with age.

    >>> res_main.query('Covariate != "Intercept" & Signif == True').round(3)
                                  Log(FC)     SE      W  pvalue  qvalue  Signif
    FeatureID Covariate
    F2        status[T.moderate]     1.906  0.259  7.371   0.000   0.000    True
              status[T.severe]       2.935  0.304  9.649   0.000   0.000    True
    F3        age                    0.063  0.022  2.871   0.004   0.033    True

    **Global test**

    Next, we will perform a *global test* to identify features that are differentially
    abundant between at least two status.

    >>> res_global = res.global_test()
    >>> res_global.round(3)
                    W  pvalue  qvalue  Signif
    FeatureID
    F1          5.934   0.103   0.617   False
    F2         95.473   0.000   0.000    True
    F3          3.210   0.402   1.000   False
    F4          0.503   0.445   1.000   False
    F5          6.839   0.065   0.458   False
    F6          0.631   0.541   1.000   False
    F7          1.044   0.813   1.000   False
    F8          0.548   0.479   1.000   False

    The global test result suggests that "F2" is differentially abundant between two of
    the three groups (though it doesn't tell you which groups).

    **Structural zero test**

    The structural zero test identifies features that are systematically absent from
    certain sample groups. This test is an option of the R command ``ancombc``. In
    scikit-bio, :func:`struc_zero` is a standalone function, as it is generally useful
    with or without ANCOM-BC.

    >>> from skbio.stats.composition import struc_zero
    >>> res_zero = struc_zero(table, metadata, 'status')
    >>> res_zero
                mild  moderate  severe
    FeatureID
    F1         False     False   False
    F2         False     False   False
    F3         False     False   False
    F4         False     False   False
    F5         False     False    True
    F6         False     False   False
    F7         False     False   False
    F8         False     False   False

    The result reveals that feature "F5" is a structural zero in the "severe" groups,
    as all or most of its values are zero. Although the ANCOM-BC test itself didn't
    identify "F5", we should consider it as differentially (less) abundant than in the
    other two groups.

    We can use this additional information to update the global test result. The rule
    is that a feature should be considered as globally differentially abundant if it is
    a structural zero in at least one but not all groups.

    >>> signif_global = res_global['Signif'] | (
    ...     ~res_zero.all(axis=1) & res_zero.any(axis=1))
    >>> signif_global
    FeatureID
    F1    False
    F2     True
    F3    False
    F4    False
    F5     True
    F6    False
    F7    False
    F8    False
    dtype: bool

    The main ANCOM-BC result can also be updated with structural zeros.

    >>> signif_main = res_main.query(
    ...     'Covariate.str.startswith("status[T.")')['Signif'].unstack()
    >>> signif_main.columns = signif_main.columns.str.removeprefix(
    ...     'status[T.').str.removesuffix(']')
    >>> signif_zero = res_zero.loc[signif_main.index, signif_main.columns]
    >>> signif_main |= signif_zero
    >>> signif_main.columns.name = None
    >>> signif_main
               moderate  severe
    FeatureID
    F1            False   False
    F2             True    True
    F3            False   False
    F4            False   False
    F5            False    True
    F6            False   False
    F7            False   False
    F8            False   False

    """
    return _ancombc_core(
        table=table,
        metadata=metadata,
        formula=formula,
        v2=False,
        grouping=grouping,
        max_iter=max_iter,
        tol=tol,
        alpha=alpha,
        p_adjust=p_adjust,
    )


def ancombc2(
    table,
    metadata,
    formula,
    grouping=None,
    pseudocount=0,
    aggregator=None,
    var_quantile=0.05,
    max_iter=100,
    tol=1e-5,
    p_adjust="holm",
    alpha=0.05,
):
    r"""Perform differential abundance test using ANCOM-BC2.

    Analysis of Compositions of Microbiomes with Bias Correction 2 (ANCOM-BC2) [1]_
    extends ANCOM-BC by explicitly estimating sample-specific sampling fractions,
    correcting the transformed abundance data by these estimates, and refitting the
    model before inference.

    .. versionadded:: 0.7.4

    Parameters
    ----------
    table : table_like of shape (n_samples, n_features)
        Matrix containing count or proportional abundance data of the samples.
    metadata : pd.DataFrame or 2-D array_like
        Metadata of the samples. Rows correspond to samples and columns correspond
        to covariates (attributes). Must be a pandas DataFrame or convertible to a
        pandas DataFrame.
    formula : str or generic Formula object
        Formula defining the model using factors included in the metadata columns.
        Refer to `Patsy's documentation
        <https://patsy.readthedocs.io/en/latest/formulas.html>`_ on how to specify
        a formula.
    grouping : str, optional
        Metadata column defining sample groups for post-hoc analyses. Must be a term
        in ``formula`` and contain at least three groups. Other terms are treated as
        adjustment covariates. It has no impact on the main result. If None (default),
        post-hoc analyses will be unavailable.
    pseudocount : int or float, optional
        Pseudocount to add to all abundance data. Default is 0.
    aggregator : callable, mapping, or 1-D array_like, optional
        Rule for aggregating features before final regression. Can be a function or a
        dictionary that maps each feature ID to an aggregate ID, or a plain list or
        array of aggregate ID per feature in table order. By default, no aggregation
        is performed.
    var_quantile : float, optional
        Quantile of coefficient variances used as a regularization factor to reduce
        spurious significance from extremely small standard errors, particularly for
        rare features. Must be between 0 and 1. Set to 0 to disable. Default is 0.05.
    max_iter : int, optional
        Maximum number of iterations for the bias estimation process. Default is 100.
    tol : float, optional
        Absolute convergence tolerance for the bias estimation process. Default is
        1e-5.
    alpha : float, optional
        Significance level for the statistical tests. Must be in the range of (0, 1).
        Default is 0.05.
    p_adjust : str, optional
        Method to correct *p*-values for multiple comparisons. Options are: Bonferroni
        ("bonf"/"bonferroni"), Holm-Bonferroni ("holm"/"holm-bonferroni", default),
        Benjamini-Hochberg ("bh"/"benjamini-hochberg"), and Benjamini-Yekutieli
        ("by"/"benjamini-yekutieli"), or any method supported by statsmodels'
        :func:`~statsmodels.stats.multitest.multipletests` function. Case-insensitive.
        If None, no correction will be performed.

    Returns
    -------
    :class:`ANCOMBCResult`
        Result object with primary results and post-hoc analysis methods.

    See Also
    --------
    ancombc : ANCOM-BC without explicit sampling-fraction correction.
    struc_zero : Standalone structural zero detection.

    Notes
    -----
    This function is a Python re-implementation of the ANCOM-BC2 method [1]_, which was
    originally implemented in the R package ``ANCOMBC``. This function provides an
    efficient and scalable algorithm, with a simple interface consistent with other
    scikit-bio components. The output of this function should match that of the R
    package.

    Comparing with the R command ``ancombc2``, which completes the entire workflow in
    one go with extensive parameter settings, this function only executes the core
    ANCOM-BC2 algorithm and reports the primary results, while:

    1. Filtering of samples and features should be completed by the user prior to the
       function call.

    2. Post-hoc analyses (global test, pairwise test, Dunnett's test and trend test)
       are available as methods of the result object.

    3. The structural zero test is available as a standalone function
       :func:`struc_zero`.

    4. Pseudocount sensitivity analysis is performed by repeating function calls with
       alternative ``pseudocount`` settings and merging the results.

    A comprehensive tutorial on running the ANCOM-BC2 analysis and matching the R
    workflow is provided in the "Examples" section below.

    References
    ----------
    .. [1] Lin, H., & Peddada, S. D. (2024). Multigroup analysis of compositions of
       microbiomes with covariate adjustments and repeated measures. Nature Methods,
       21(1), 83-91.

    Examples
    --------
    >>> from skbio.stats.composition import ancombc2, struc_zero
    >>> import pandas as pd

    Consider a dataset with 15 samples and eight features. The counts are sparse and
    skewed. Samples belong to three disease-status groups, while age is included as a
    potential confounder.

    >>> samples = [f"S{i}" for i in range(1, 16)]
    >>> features = [f"F{i}" for i in range(1, 9)]
    >>> data = [
    ...     [1, 10, 16, 0, 0, 12, 0, 7],
    ...     [0, 10, 45, 2, 1, 25, 1, 9],
    ...     [4,  8, 22, 1, 5, 14, 1, 5],
    ...     [1, 11, 22, 1, 4, 14, 1, 3],
    ...     [4,  7, 36, 0, 0, 19, 0, 9],
    ...     [2, 30, 26, 0, 0, 12, 1, 0],
    ...     [1, 36, 10, 1, 5, 15, 2, 9],
    ...     [1, 25, 11, 2, 2,  8, 0, 5],
    ...     [1, 36, 23, 0, 2, 11, 1, 2],
    ...     [3, 60, 33, 3, 4, 14, 1, 6],
    ...     [3, 57, 30, 3, 1,  3, 0, 4],
    ...     [0, 65, 23, 0, 2,  2, 0, 8],
    ...     [2, 46, 19, 0, 1,  2, 0, 1],
    ...     [0, 41, 26, 0, 2,  0, 0, 3],
    ...     [3, 46, 20, 0, 0,  3, 0, 0],
    ... ]
    >>> table = pd.DataFrame(data, index=samples, columns=features)
    >>> status = ["mild"] * 5 + ["moderate"] * 5 + ["severe"] * 5
    >>> age = [25, 48, 23, 35, 52, 51, 18, 29, 40, 29, 44, 39, 26, 37, 46]
    >>> metadata = pd.DataFrame({"status": status, "age": age}, index=samples)

    **Pre-processing**

    Before start, refer to the documentation of :func:`ancombc` on data pre-processing,
    such as filtering samples by total abundance, filtering features by prevalence, and
    defining the reference level of a categorical column in the metadata.

    There are two differences from ``ancombc``: First, a ``pseudocount`` parameter is
    present in ``ancombc2``, defaulting to zero. There is no need to add a pseudocount
    to the data table prior to the analysis.

    Second, an ``aggregator`` parameter automates data aggregation within the function
    call. Aggregating data manually before the analysis will produce different output.
    This is because ``ancombc2`` estimates initial model parameters on raw data before
    it aggregates them for final parameter estimation.

    **Primary analysis**

    Fit disease status while adjusting for age. Specifying ``grouping="status"`` also
    enables post-hoc analyses for this factor. The alphabetically first level ``mild``
    serves as the reference group. When done, display the primary result table.

    >>> res = ancombc2(table, metadata, formula="status + age", grouping="status")
    >>> res_main = res.result
    >>> res_main.round(3)
                                Log(FC)     SE      W  pvalue  qvalue  Signif
    FeatureID Covariate
    F1      Intercept             0.329  0.788  0.417   0.687   1.000   False
            status[T.moderate]   -0.130  0.428 -0.305   0.768   1.000   False
            status[T.severe]      0.450  0.446  1.010   0.342   1.000   False
            age                  -0.004  0.021 -0.193   0.852   1.000   False
    F2      Intercept            -0.097  0.514 -0.189   0.854   1.000   False
            status[T.moderate]    1.578  0.287  5.503   0.000   0.001    True
            status[T.severe]      1.880  0.300  6.272   0.000   0.000    True
            age                  -0.024  0.014 -1.794   0.100   0.703   False
    F3      Intercept             0.068  0.494  0.137   0.894   1.000   False
            status[T.moderate]   -0.054  0.271 -0.200   0.845   1.000   False
            status[T.severe]     -0.004  0.297 -0.014   0.989   1.000   False
            age                   0.004  0.014  0.248   0.809   1.000   False
    F4      Intercept            -0.990  0.781 -1.268   0.294   1.000   False
            status[T.moderate]    0.933  0.427  2.186   0.117   0.817   False
            status[T.severe]      0.600  0.516  1.164   0.329   1.000   False
            age                   0.021  0.026  0.814   0.475   1.000   False
    F5      Intercept             2.376  0.663  3.586   0.009   0.071   False
            status[T.moderate]    0.069  0.388  0.178   0.864   1.000   False
            status[T.severe]     -0.448  0.467 -0.960   0.369   1.000   False
            age                  -0.060  0.022 -2.798   0.027   0.213   False
    F6      Intercept             1.117  0.522  2.141   0.058   0.406   False
            status[T.moderate]   -0.075  0.283 -0.264   0.797   1.000   False
            status[T.severe]     -1.729  0.343 -5.042   0.001   0.004    True
            age                  -0.012  0.016 -0.729   0.483   1.000   False
    F7      Intercept             0.834  0.787  1.060   0.349   1.000   False
            status[T.moderate]    0.348  0.440  0.791   0.473   1.000   False
            status[T.severe]      0.000  0.516  0.000   1.000   1.000   False
            age                  -0.025  0.026 -0.957   0.393   1.000   False
    F8      Intercept             0.775  0.714  1.084   0.306   1.000   False
            status[T.moderate]    0.028  0.411  0.069   0.947   1.000   False
            status[T.severe]     -0.530  0.444 -1.193   0.263   1.000   False
            age                  -0.013  0.021 -0.609   0.558   1.000   False

    ``res`` is an instance of :class:`ANCOMBCResult`. It behaves like its primary
    result table ``res.result`` for display and column selection. Here we display only
    significant feature-covariate pairs:

    >>> res[res["Signif"]].round(3)
                                  Log(FC)     SE      W  pvalue  qvalue  Signif
    FeatureID Covariate
    F2        status[T.moderate]    1.578  0.287  5.503   0.000   0.001    True
              status[T.severe]      1.880  0.300  6.272   0.000   0.000    True
    F6        status[T.severe]     -1.729  0.343 -5.042   0.001   0.004    True

    ``Log(FC)`` is the estimated coefficient on the natural-log scale. As shown, F2 is
    more abundant in both moderate and severe samples than in mild samples after
    adjusting for age, while F6 is less abundant in severe samples.

    **Global test**

    The global test asks whether a feature differs between at least two of the three
    status groups, without identifying which groups differ.

    >>> res_global = res.global_test()
    >>> res_global.round(3)
                    W  pvalue  qvalue  Signif
    FeatureID
    F1          1.786   0.457   1.000   False
    F2         60.287   0.000   0.000    True
    F3          0.040   0.078   0.469   False
    F4          4.780   0.233   1.000   False
    F5          1.385   0.623   1.000   False
    F6         25.906   0.000   0.002    True
    F7          0.865   0.975   1.000   False
    F8          1.589   0.513   1.000   False

    This identifies F2 and F6 as globally differentially abundant.

    **Pairwise test**

    The pairwise test compares every pair of status groups. In addition to the two
    comparisons against the reference group (mild), it directly compares severe with
    moderate samples.

    >>> res_pair = res.pairwise_test()
    >>> cols = ["Log(FC)", "qvalue", "Signif"]
    >>> res_pair.loc[res_pair["Signif"], cols].round(3)
                                                   Log(FC)  qvalue  Signif
    FeatureID Comparison
    F2        status[T.moderate]                     1.578   0.002    True
              status[T.severe]                       1.880   0.001    True
    F6        status[T.severe]                      -1.729   0.006    True
              status[T.severe]_status[T.moderate]   -1.654   0.023    True

    Thus, F6 is not only depleted in severe samples relative to mild samples, but also
    relative to moderate samples.

    **Dunnett's test**

    Dunnett's test is useful when the scientific question specifically concerns each
    group versus a reference group (mild). It therefore omits the severe-vs-moderate
    comparison. A seed is supplied because the procedure uses bootstrapping.

    >>> res_dunn = res.dunnett_test(seed=42)
    >>> res_dunn[res_dunn["Signif"]].round(3)
                                  Log(FC)     SE      W  pvalue  qvalue  Signif
    FeatureID Comparison
    F2        status[T.moderate]    1.578  0.287  5.503   0.000   0.001    True
              status[T.severe]      1.880  0.300  6.272   0.000   0.000    True
    F6        status[T.severe]     -1.729  0.343 -5.042   0.001   0.004    True

    **Trend test**

    Finally, the status column has a natural mild-to-moderate-to-severe ordering. The
    trend test evaluates ordered patterns in group effects. Here this ordering also
    matches the factor level order used by the fitted model.

    >>> res_trend = res.trend_test(seed=42)
    >>> res_trend.round(3)
                   W  pvalue  qvalue  Signif
    FeatureID
    F1         0.513    0.28    1.00   False
    F2         1.880    0.00    0.00    True
    F3         0.031    1.00    1.00   False
    F4         0.833    0.13    0.78   False
    F5         0.485    0.32    1.00   False
    F6         1.729    0.00    0.00    True
    F7         0.232    0.79    1.00   False
    F8         0.539    0.23    1.00   False

    The trend test again identifies F2 and F6, consistent with their increasing and
    decreasing abundance patterns across disease severity, respectively.

    **Structural zero test**

    The structural zero test supplied by the standalone function :func:`struc_zero`
    identifies features that are systematically absent from certain sample groups. As
    we may notice, F7 is absent from every severe sample but remains present in the
    mild and moderate groups. This information can be captured by the structural zero
    test:

    >>> struc_zero(table, metadata, "status").loc["F7"]
    mild        False
    moderate    False
    severe       True
    Name: F7, dtype: bool

    Refer to the documentation of :func:`ancombc` on updating test results with
    identified structural zeros.

    **Pseudocount sensitivity analysis**

    The choice of pseudocount can affect differential abundance results. A sensitivity
    analysis repeats the complete analysis using multiple pseudocounts. A result is
    considered "pass" when its significance decision is identical across all analyses,
    and is marked as "robust" when it is consistently significant.

    .. note::
        This approach corresponds to the procedure used by ANCOMBC 2.10.1 and later.
        Earlier versions added alternative pseudocounts after bias correction. Since
        2.10.1, each pseudocount is added before bias correction and the full analysis
        is repeated.

    In addition to the default analysis (with the default ``pseudocount=0``), run the
    analysis on three pseudocounts: 0.1, 0.5 and 1.0, following the ANCOMBC package:

    >>> fits = [ancombc2(table, metadata, formula='status + age', grouping='status',
    ...         pseudocount=p) for p in (0.1, 0.5, 1)]
    >>> signif = pd.concat([x.result["Signif"] for x in fits], axis=1)

    Compare with the default analysis and append the output to the primary results:

    >>> res_main["Pass"] = signif.eq(res_main["Signif"], axis=0).all(axis=1)
    >>> res_main["Robust"] = res_main["Signif"] & res_main["Pass"]

    The result reveals that none of the three initially significant feature-covariate
    associations is robust to the tested pseudocounts. Thus, they should be interpreted
    cautiously rather than as supported conclusions.

    >>> res_main.query("Robust == True").shape[0]
    0

    The same approach can be applied to global test, pairwise test and Dunnett's test.

    .. note::
        For trend test, the ANCOMBC package uses the global test sensitivity decision
        rather than repeating the stochastic trend test at each pseudocount.

    More broadly, the sensitivity analysis can also be used with :func:`ancombc` and
    other analyses involving pseudocounts.

    Sensitivity analysis can substantially reduce the number of significant results and
    thereby lower the risk of pseudocount-driven false positives, but this conservatism
    may reduce power and yield fewer significant results. The ANCOM-BC2 authors
    strongly recommend incorporating sensitivity analysis into the final assessment of
    taxon significance, unless maximizing power is the primary goal.

    **Variance regularization**

    Another mechanism for reducing the risk of false positives is the ``var_quantile``
    parameter (corresponding to the R package's ``s0_perc`` parameter), which adds the
    selected quantile (default: 0.05) of coefficient variances to the variance before
    inference. This helps reducing spurious significance caused by extremely small
    standard errors, especially for rare features. Larger values generally make the
    analysis more conservative and can further reduce false positives, but may also
    reduce statistical power.

    """
    return _ancombc_core(
        table=table,
        metadata=metadata,
        formula=formula,
        v2=True,
        grouping=grouping,
        aggregator=aggregator,
        max_iter=max_iter,
        tol=tol,
        alpha=alpha,
        p_adjust=p_adjust,
        pseudo=pseudocount,
        var_quantile=var_quantile,
    )


def _ancombc_core(
    table,
    metadata,
    formula,
    v2=False,
    grouping=None,
    aggregator=None,
    p_adjust="holm",
    pseudo=0,
    var_quantile=0.05,
    match_r=True,
    alpha=0.05,
    max_iter=100,
    tol=1e-5,
):
    """ANCOM-BC/BC2 core function.

    Parameters
    ----------
    match_r : bool, optional
        How to handle rank-deficient feature-specific regressions. Relevant when input
        data table contain zeros.

        - True (default) reproduces R package ANCOMBC's behavior, which reduces a
          categorical predictor to one observed level. For ordinary additive treatment-
          coded factors, it also uses the first remaining level in the Patsy-processed
          formula as a feature-local reference when the global reference is absent.

        - False keeps the Moore-Penrose fit and suppresses only coefficients that are
          not uniquely estimable.

    Notes
    -----
    By default (`match_r=True`), scikit-bio mirrors the R code when this omission
    leaves a categorical predictor with only one observed level: the entire feature
    fit is unavailable, with `Log(FC)`, `SE` and `W`` reported as NaN, `pvalue` and
    `qvalue` as 1, and `Signif` as False.

    If an ordinary additive treatment-coded factor retains multiple levels but loses
    its global reference, the first remaining level in Patsy's category order is used
    as a feature-local reference before bias estimation. This often happens when the
    data is highly sparse and certain features are zeros within the entire reference
    group. This reference rebasing is intentionally not applied to interactions or
    custom contrasts, whose coefficient bases require a joint transformation.

    The alternative mode `match_r=False` retains the Moore-Penrose fit instead and
    suppresses only coefficients that are not uniquely estimable. This mode differs
    from R's handling of rank deficiency. Its implications for bias estimation and
    downstream inference require further validation.

    """
    # Validate parameters
    if not 0 < alpha < 1:
        raise ValueError(f"`alpha`={alpha} is not within 0 and 1.")
    if not 0 <= var_quantile <= 1:
        raise ValueError("`var_quantile` must be between 0 and 1.")
    if not pseudo >= 0:
        raise ValueError(f"Pseudocount must be a non-negative number.")

    matrix, samples, features = _ingest_table(table)

    # ANCOM-BC does not handle zeros in the input table. The user should have added a
    # pseudocount. ANCOM-BC2 can handle zeros.
    _check_composition(np, matrix, nozero=not v2)

    # Validate metadata.
    metadata = _check_metadata(metadata, matrix, samples)

    # Transform data
    data, missing = _transform_data(matrix, pseudo, center=v2)

    # Create a design matrix based on metadata and formula.
    dmat = _build_dmatrix(formula, metadata, dtype=data.dtype)

    # Obtain a list of covariates by selecting the relevant columns.
    covars = dmat.design_info.column_names
    n_covars = len(covars)

    # Validate sample grouping for post-hoc analysis
    # When provided, only this coefficient covariance submatrix is retained.
    groups = _validate_grouping(metadata, dmat, grouping)

    # Estimate initial model parameters.
    # ANCOM-BC2 always re-estimates parameters after sampling fraction correction, so
    # its initial EM fit needs variances only. For ANCOM-BC this is the final fit, so
    # retain the grouping covariance submatrix when post-hoc analysis was requested.
    # Data matrix will be overwritten during dense parameter estimation. However it is
    # needed for sampling fraction estimation in the ANCOM-BC2 route. Therefore `v2`
    # instructs the function to make a copy.
    var_hat, beta, _, vcov_hat, estimable, _ = _estimate_params(
        data, dmat, None if v2 else groups, missing, True, v2, match_r
    )

    # `None` enables a fast path without masking/allocation.
    if estimable is not None and np.all(estimable):
        estimable = None

    # Estimate and correct for sampling bias via expectation-maximization (EM).
    # beta: (n_covariates, n_features); iterate over covariates (rows).
    # Two concise paths are kept for performance: The overwhelmingly common full-rank
    # path calls the existing EM routine unchanged. Only when sparse feature-specific
    # models lose estimability do we subset those coefficient/variance pairs before EM.
    # This avoids putting NaN-aware reductions inside the dominant EM loop.
    # TODO: Check for numerical failures caused by extreme data, such as constant
    # abundance values, extremely large values, one varying feature, etc.
    bias = np.empty((n_covars, 3), dtype=beta.dtype)
    for i in range(n_covars):
        if estimable is None:
            beta_i = beta[i]
            var_i = var_hat[:, i]
        else:
            valid = estimable[:, i] & np.isfinite(var_hat[:, i])
            if not np.any(valid):
                raise ValueError(
                    f"No estimable features remain for covariate {covars[i]!r}. "
                    "Consider a more parsimonious model or a positive pseudocount."
                )
            beta_i = beta[i, valid]
            var_i = var_hat[valid, i]
        bias[i] = _estimate_bias_em(beta_i, var_i, tol=tol, max_iter=max_iter)

    delta_em, delta_wls, var_delta = bias[:, 0], bias[:, 1], bias[:, 2]

    # ANCOM-BC (original)
    if not v2:
        # Correct coefficients (logFC) according to estimated bias.
        beta_hat = beta.T - delta_em
        dof = None

    # ANCOM-BC2
    else:
        # Estimate sampling fractions
        theta_hat = _sample_fractions(
            data, dmat, beta, delta_em, missing, estimable, match_r
        )

        # Aggregate data
        # ANCOM-BC2 aggregates data after initial parameter estimation. Therefore,
        # pre-aggregation of data before running `ancombc2` will produce different
        # results. This does not affect ANCOM-BC.
        if aggregator is not None:
            matrix, features = _aggregate_features(matrix, aggregator, features)
            data, missing = _transform_data(matrix, pseudo, center=v2)

        # Correct data for sampling fractions
        data -= theta_hat[:, None]

        # Re-estimate parameters.
        # Since this is the final fit, skip sampling fraction estimation, and retain
        # the grouping covariance submatrix if requested.
        var_hat, beta_hat, _, vcov_hat, estimable, rank = _estimate_params(
            data, dmat, groups, missing, False, False, match_r
        )
        if estimable is not None and np.all(estimable):
            estimable = None
        beta_hat = beta_hat.T

        # Adjust variances
        _adjust_variance(var_hat, vcov_hat, var_delta, var_quantile, groups)

        # Compute per-feature degree of freedom (observed samples - covariates)
        if missing is not None:
            n_valid = missing.shape[0] - np.sum(missing, axis=0)
            # A partially rank-deficient feature can still have uniquely estimable
            # coefficients. Its residual degrees of freedom depend on the actual
            # feature-specific design rank rather than the nominal number of columns.
            model_rank = n_covars if rank is None else rank
            dof = np.where(n_valid > model_rank, n_valid - model_rank, np.nan)
        else:
            n_samps = matrix.shape[0]
            dof = n_samps - n_covars if n_samps > n_covars else np.nan

    # Calculate statistics
    # Reuse fitting arrays when they are not needed for post-hoc analyses.
    lfc, se, W, pval, qval, reject = _calc_statistics(
        beta_hat, var_hat, alpha, p_adjust, dof, estimable, inplace=groups is None
    )

    # Output primary results
    # TODO: Consider constructing table in ANCOMBCResult.__init__
    if features is None:
        features = np.arange(matrix.shape[1])
    index = pd.MultiIndex.from_product(
        (features, covars), names=("FeatureID", "Covariate")
    )
    # NOTE: Some arrays are F-contiguous and copies are made by .ravel()
    columns = {
        "Log(FC)": lfc.ravel(),
        "SE": se.ravel(),
        "W": W.ravel(),
        "pvalue": pval.ravel(),
        "qvalue": qval.ravel(),
        "Signif": pd.array(reject.ravel(), dtype="boolean"),
    }
    res = pd.DataFrame(columns, index=index, copy=False)

    method = "ANCOM-BC" if not v2 else "ANCOM-BC2"

    state = {}
    if groups is not None:
        state = dict(
            _dmat=dmat,
            _beta_hat=beta_hat,
            _var_hat=var_hat,
            _vcov_hat=vcov_hat,
            _groups=groups,
            _dof=dof,
            _estimable=estimable,
        )
    return ANCOMBCResult(
        result=res,
        method=method,
        _features=features,
        _covariates=covars,
        _p_adjust=p_adjust,
        _alpha=alpha,
        **state,
    )


def _validate_grouping(metadata, dmat, grouping):
    """Validate a post-hoc grouping and return its design-matrix column indices."""
    if grouping is None:
        return None
    if not isinstance(grouping, str):
        raise TypeError("`grouping` must be a metadata column name or None.")
    if grouping not in metadata.columns:
        raise ValueError("`grouping` is not a metadata column.")
    try:
        s = dmat.design_info.term_name_slices[grouping]
    except KeyError:
        raise ValueError("`grouping` must be a term in `formula`.")
    if metadata[grouping].nunique(dropna=True) < 3:
        raise ValueError("`grouping` must contain at least three observed groups.")
    idx = np.arange(s.start, s.stop)
    if idx.size < 2:
        raise ValueError(
            f"`grouping`={grouping!r} does not produce at least two covariates in "
            "the design matrix. Make sure it is modeled as a categorical factor."
        )
    return idx


def _transform_data(data, pseudo=None, center=False):
    """Transform abundance data table.

    Parameters
    ----------
    data : ndarray of shape (n_samples, n_features)
        Data table.
    pseudo : float or int, optional
        Pseudocount.
    center : bool, optional
        If True, center data at 0 for each feature.

    Returns
    -------
    data : ndarray of shape (n_samples, n_features)
        Transformed data table.
    missing : ndarray of shape (n_samples, n_features) or None
        Boolean mask of zero values in the table, or None if the table is zero-free or
        a pseudocount is added.

    Notes
    -----
    For ANCOM-BC, a simple log-transform is applied. For ANCOM-BC2, the log-transformed
    data is centered at 0 per feature. This is equivalent to `rclr(data, axis=0)`, but
    more efficient.

    The returned `data` is a new float32 or float64 table. Floating inputs no wider
    than float32 use float32; wider floating inputs and integer inputs use float64. The
    original data table is kept intact.

    """
    ### Step 1: Identify zero values and/or add pseudocount. ###

    # Cast data into float64 (default, including integer input) or float32 (float input
    # <= 32 bit).
    # NOTE: NumPy linear algebra does not support float16.
    # TODO: Consider having a utility function of this.
    dtype = data.dtype
    if (
        np.issubdtype(dtype, np.floating)
        and dtype.itemsize <= np.dtype(np.float32).itemsize
    ):
        dtype = np.dtype(np.float32)
    else:
        dtype = np.dtype(np.float64)

    # Add pseudocount if provided. Always make a new floating-point array so the input
    # table remains untouched.
    if pseudo:
        data = data.astype(dtype, copy=True)
        data += pseudo
        missing = None

    # Otherwise, identify zero values and make a floating-point copy of data.
    else:
        missing = data == 0
        if not np.any(missing):
            missing = None
        data = data.astype(dtype, copy=True)

    ### Step 2: Log-transform observed data and optionally center ###

    # Fill missing values with 1 for safe log (they become 0)
    if missing is not None:
        np.copyto(data, 1.0, where=missing)  # faster than `data[missing] = 1.0`

    # Log-transform in place
    np.log(data, out=data)

    # Center at 0 (subtract by feature mean) in place
    if center:
        if missing is None:
            mean_ = np.mean(data, axis=0, keepdims=True)
        else:
            n_obs = data.shape[0] - np.sum(missing, axis=0, keepdims=True)

            # Avoid zero division warning by empty features
            n_obs = np.where(n_obs > 0, n_obs, 1)

            mean_ = np.sum(data, axis=0, keepdims=True)
            mean_ /= n_obs
        data -= mean_

    # Fill missing values with NaN
    # TODO: This is not needed except for `_sample_fractions`
    if missing is not None:
        np.copyto(data, np.nan, where=missing)

    return data, missing


def _estimate_params(
    data, dmat, groups, missing, biased=True, keep_data=True, match_r=True
):
    """Estimate model parameters.

    In ANCOM-BC, this function is used for initial estimation of model parameters
    (coefficients, variances and mean residuals) based on the observed data.

    In ANCOM-BC2, this function is additionally used for final parameter estimation on
    data corrected for sampling fractions.

    Parameters
    ----------
    data : ndarray of shape (n_samples, n_features)
        Transformed data table.
    dmat : ndarray of shape (n_samples, n_covariates)
        Design matrix.
    groups : ndarray of shape (n_groups - 1,), bool, or None
        Indices of coefficients in the design matrix whose covariance submatrix will
        be calculated. If True, the entire covariance matrix will be calculated. If
        None, no covariance will be returned.
    missing : ndarray of shape (n_samples, n_features), or None
        Boolean mask of zero values in the pre-transformation data table, or None if
        the table is zero-free or a pseudocount was applied.
    biased : bool, optional
        Whether to estimate sample-specific biases (theta). Only the initial fit needs
        this (True). ANCOM-BC2's final fit considers biases as already corrected and
        theta = 0 (False).
    keep_data : bool, optional
        If True, the original data table will be kept intact. Relevant when `missing`
        is not provided (dense route). Sparse route always keeps the data table.
    match_r : bool, optional
        Rank-deficiency handling policy for sparse feature-specific regressions.

    Returns
    -------
    var_hat : ndarray of shape (n_features, n_covariates)
        Estimated variances of regression coefficients.
    beta : ndarray of shape (n_covariates, n_features)
        Estimated coefficients (log-fold changes).
    theta : ndarray of shape (n_samples,)
        Per-sample mean residuals of estimated data.
    covmat : ndarray or None
        Estimated covariance matrices of coefficients.
        - When `groups=None`: None.
        - When `groups=True`: Full covariance matrices.
          Shape: (n_features, n_covariates, n_covariates)
        - When `groups` is ndarray of indices: Covariance submatrices of the indices.
          Shape: (n_features, n_groups - 1, n_groups - 1)
    estimable : ndarray of bool or None
        For sparse data, indicates which feature-covariate coefficients are retained
        for inference when `match_r=True`. Dense data return None.
    rank : ndarray of int or None
        Feature-specific masked-design ranks for sparse data. Dense data return None.

    Notes
    -----
    Returned `var_hat` is F-contiguous, which should presumably benefit the downstream
    EM optimization process.
    """
    if missing is not None:
        return _estimate_params_sparse(
            data, dmat, missing, groups, biased, match_r=match_r
        )
    if keep_data:
        data = data.copy()
    result = _estimate_params_dense(data, dmat, groups, biased)
    return (*result, None, None)


def _estimate_params_dense(data, dmat, groups=True, biased=True):
    """Estimate model parameters from a dense matrix (no missing values).

    The original R code performs iterative maximum likelihood estimation to calculate
    the coefficients, and calls MASS:ginv to calculate the pseudo inverse Gram matrix
    using the Moore-Penrose method. We noticed that the former can be replaced with
    ordinary least squares by NumPy's `lstsq`; and the latter matches the method by
    NumPy's `pinv`. We further noticed that both functions perform singular value
    decomposition (SVD). Therefore, the following code only performs SVD once, and
    uses the intermediates to calculate coefficients and inverse Gram matrix.

    With ``biased=False``, sampling fractions have already been corrected, so
    residuals are squared without further sample-wise centering.

    NOTE: This function overwrites the data table.
    """
    # Calculate coefficients using least-squares fitting
    dmat_inv, _ = _lstsq_dense(dmat)
    beta = dmat_inv @ data

    # Calculate residuals = data - fitted data
    # The process below is equivalent to `data -= dmat @ beta` but saves memory by
    # avoiding materializing the entire fitted matrix.
    _calc_residual(data, dmat, beta)

    # Estimate sample effects only in the initial fit. The final fit must retain
    # the supplied correction, even if aggregation leaves nonzero mean residuals.
    if biased:
        theta = np.mean(data, axis=1)
        data -= theta[:, None]
    else:
        theta = np.zeros(data.shape[0], dtype=data.dtype)

    np.square(data, out=data)

    # Calculate variances and covariance matrix of coefficients
    var_hat, covmat = _calc_grouped_var_cov(data, dmat_inv.T, groups)

    return var_hat, beta, theta, covmat


def _estimate_params_sparse(
    data,
    dmat,
    missing,
    groups=True,
    biased=True,
    match_r=True,
    direct=False,
    batch=True,
    tol=1e-2,
    max_iter=20,
):
    """Estimate model parameters from a sparse matrix (with missing values).

    This mirrors the fixed-effects ``.iter_mle`` path used by ANCOM-BC2 when
    ``theta`` is initially ``NULL``. The input ``data`` is expected to already
    be log-transformed and centered, with zeros represented by ``NaN``.

    Parameters
    ----------
    direct : bool, optional
        If True, directly solve the coupled sample effects with exact linear algebra.
        If False (default), using an iterative approach to approximate the solution,
        (matching ANCOM-BC2).
    batch : int or bool, optional
        Number of features per batch for masked SVD. If True (default), batch size will
        be automatically determined such that the memory consumption is about 32 MiB.
        If compares False, batched SVD will be disabled and a full feature-by-sample
        array will be computed.
    tol : float, optional
        Iteration tolerance. Default is 1e-2 (matching ANCOM-BC2).
    max_iter : int, optional
        Maximum number of iterations. Default is 20 (matching ANCOM-BC2).

    Returns
    -------
    var_hat : ndarray of shape (n_features, n_covariates)
        Estimated variances of regression coefficients.
    beta : ndarray of shape (n_covariates, n_features)
        Estimated regression coefficients.
    theta : ndarray of shape (n_samples,)
        Per-sample mean residuals / initial sampling-fraction estimates.
    covmat : ndarray or None
        Estimated covariance matrices of coefficients.

    """
    # Fit missing-response model. The SVD already needed by the sparse solver also
    # identifies which individual coefficients are uniquely estimable. Keeping this
    # information separate from the finite Moore-Penrose solution lets the numerical
    # core remain fast while preventing arbitrary minimum-norm coefficients from being
    # exposed as statistical estimates.
    func = _lstsq_sparse_batch if batch else _lstsq_sparse
    theta, beta, estimable, rank = func(
        data, dmat, missing, direct, batch, biased, match_r, tol, max_iter
    )

    # Calculate residuals
    intm = _calc_residual_sparse(data, dmat, beta, theta, missing)

    # Important R detail: .iter_mle uses ONE global ginv(X.T @ X), not a
    # feature-specific inverse based on each feature's observed rows. Its transpose is
    # the influence matrix H used by the GEMM covariance calculation below.
    dmat_inv, gram_sum = _lstsq_dense(dmat, gram=True)
    n_missing = missing.sum(axis=0)

    # Calculate variances and covariance matrix of coefficients
    var_hat, covmat = _calc_grouped_var_cov(intm, dmat_inv.T, groups)

    # This code matches R, which replaces every NaN element of resid^2 * x x^T with
    # 0.1. Since dmat is finite, each missing residual contributes a matrix filled with
    # 0.1 before transformation.
    if np.any(n_missing):
        var_hat += (0.1 * n_missing)[:, None] * (gram_sum * gram_sum)[None, :]
        if covmat is not None:
            gram_sum_cov = gram_sum if groups is True else gram_sum[groups]
            missing_cov = np.outer(gram_sum_cov, gram_sum_cov)
            covmat += (0.1 * n_missing)[:, None, None] * missing_cov

    if match_r and estimable is not None:
        # When stats::lm fails, R substitutes NA fitted values for the *entire* feature.
        # Its sandwich loop then replaces every NA element of every sample contribution
        # by 0.1. Although these failed-feature variances are hidden from the final
        # table, they are still present when R computes the s0 variance quantile, so
        # reproducing them is necessary for the SEs of otherwise estimable features.
        failed = ~np.all(estimable, axis=1)
        var_hat[failed] = (0.1 * data.shape[0]) * (gram_sum * gram_sum)
        if covmat is not None:
            gram_sum_cov = gram_sum if groups is True else gram_sum[groups]
            failed_cov = (0.1 * data.shape[0]) * np.outer(gram_sum_cov, gram_sum_cov)
            covmat[failed] = failed_cov

    # Ensure the retained covariance diagonal is exactly the same array of variances
    # used by the primary analysis, including the R missing-value correction.
    if covmat is not None:
        if groups is True:
            groups = np.arange(var_hat.shape[1])
        diag = np.arange(groups.size)
        covmat[:, diag, diag] = var_hat[:, groups]

    return var_hat, beta.T.copy(), theta, covmat, estimable, rank


def _calc_residual_sparse(data, dmat, beta, theta, missing):
    """Calculate regression residuals for sparse data.

    Missing residuals are set to zero here and handled separately below to preserve
    the R code's 0.1 correction.
    """
    resids = np.empty_like(data)
    np.matmul(dmat, beta.T, out=resids)
    resids *= -1.0
    resids += data
    resids -= theta[:, None]
    np.square(resids, out=resids)
    resids[missing] = 0.0
    return resids


def _lstsq_sparse(
    data,
    dmat,
    missing,
    direct,
    batch=None,
    biased=True,
    match_r=True,
    tol=1e-2,
    max_iter=20,
):
    """Fit missing-response models using full pseudoinverse.

    This function preserves the pre-optimization path which is exact and compact but
    is less efficient due to the materialization of 3-D arrays of shape (n_features,
    n_samples, n_covariates).
    """
    n_samps = data.shape[0]

    W = data.dtype.type(1.0) - missing.T
    X_w = dmat[None, :, :] * W[:, :, None]
    U, S, Vh = np.linalg.svd(X_w, full_matrices=False)
    S_inv = _invert_singular(S)
    rank = np.count_nonzero(S_inv, axis=1)

    if match_r:
        # stats::lm only fails wholesale when model construction itself becomes
        # impossible (most importantly, a categorical predictor collapses to one
        # observed level). Mere matrix rank deficiency does not necessarily fail an R
        # fit: lm may drop a dummy coefficient and ANCOMBC fills that slot with zero.
        valid, rebases = _r_fit_info(dmat, missing)
        estimable = (
            None
            if valid is None
            else np.broadcast_to(valid[:, None], (rank.size, dmat.shape[1]))
        )
    else:
        valid = None
        rebases = ()
        estimable = _coef_estimable(Vh, S_inv)

    V = np.swapaxes(Vh, -1, -2)
    dmat_inv = np.einsum("fpk,fk,fsk->fps", V, S_inv, U, optimize=True)

    resp = data.copy()
    np.copyto(resp, 0.0, where=missing)
    beta = np.einsum("fps,sf->fp", dmat_inv, resp, optimize=True)

    # Solve the missing response model: data[s, f] = dmat[s] @ beta[f] + theta[s] for
    # observed entries.
    # Skip and set theta = 0 if not needed.
    if not biased:
        theta = np.zeros(n_samps, dtype=data.dtype)

    # The direct route solves the coupled fixed-point system for `theta` before
    # estimating `beta`.
    elif direct:
        theta, beta = _solve_sparse(data, dmat, missing, beta, resp, W, dmat_inv, valid)

    # The iterative route alternates updates of feature coefficients `beta` and shared
    # sample effects `theta`. The compact feature operators mimicks R code.
    else:

        def func(out):
            np.einsum("fps,sf->fp", dmat_inv, resp, out=out, optimize=True)

        theta, beta = _solve_sparse_iter(
            data, dmat, missing, beta, resp, func, tol, max_iter, valid
        )

    # When zero omission removes Patsy's reference level but leaves two or more
    # levels, R refits the factor with the first remaining level as the local
    # reference and ANCOMBC maps that coefficient vector back into the global
    # slots. Re-express the Moore-Penrose solution the same way. This changes
    # coefficients used by bias estimation but preserves fitted values for every
    # observed response, so it need only be done once after the theta iteration.
    if rebases:
        _r_rebase_categorical(beta, rebases, valid)

    return theta, beta, estimable, rank


def _lstsq_sparse_batch(
    data,
    dmat,
    missing,
    direct,
    batch=True,
    biased=True,
    match_r=True,
    tol=1e-2,
    max_iter=20,
    max_cond=1e4,
):
    """Fit missing-response models with chunked SVD and compact spectral operators.

    Each feature still receives an SVD of its masked design matrix, using the exact same
    singular-value cutoff as the legacy route. Only `Vh` and inverse singular values
    are retained. The large `U` and masked-design tensors exist for one feature block
    at a time, reducing persistent storage from O(F*N*P) to O(F*P^2).

    Parameters
    ----------
    max_cond : int or float, optional
        Maximum condition number for the compact pseudoinverse calculation. Features
        with a masked design matrix exceeding this value use a full SVD pseudoinverse
        to preserve numerical accuracy. Default is 1e4.

    """
    n_samps, n_feats = data.shape
    n_covars = dmat.shape[1]
    n_comps = min(n_samps, n_covars)
    dtype = data.dtype

    Vh_all = np.empty((n_feats, n_comps, n_covars), dtype=dtype)
    S_inv_all = np.empty((n_feats, n_comps), dtype=dtype)
    # R-compatibility only needs a feature-level failed-fit mask and therefore avoids
    # the O(F * P^2) row-space projector. The finer Python policy allocates individual
    # coefficient estimability metadata.
    estimable = None if match_r else np.empty((n_feats, n_covars), dtype=bool)
    rank = np.empty(n_feats, dtype=np.intp)

    # Determine batch size
    # X_w and U are both approximately batch*N*P floats, while W contributes another
    # batch*N floats. Keep these principal workspaces near 32 MiB.
    if batch is True:
        bytes_per_feature = dtype.itemsize * n_samps * (n_covars + n_comps + 1)
        batch = max(1, (32 << 20) // max(bytes_per_feature, 1))
        batch = min(batch, n_feats)

    # Mark features whose masked design is ill-conditioned, such that a batched
    # solution is unstable, and a full SVD solution will be needed.
    illed = {}

    for start in range(0, n_feats, batch):
        stop = min(start + batch, n_feats)
        W_block = dtype.type(1.0) - missing[:, start:stop].T
        X_w = dmat[None, :, :] * W_block[:, :, None]
        U, S, Vh = np.linalg.svd(X_w, full_matrices=False)
        S_inv = _invert_singular(S)
        Vh_all[start:stop] = Vh
        S_inv_all[start:stop] = S_inv

        # A coefficient beta_j is uniquely identifiable iff its coordinate vector e_j
        # lies in the row space of the feature-specific design. The diagonal of the
        # row-space projector V_r V_r.T gives this test using the SVD we already paid
        # for, so the extra cost is only O(batch * P^2) with a tiny boolean output.
        rank_block = np.count_nonzero(S_inv, axis=1)
        rank[start:stop] = rank_block
        if estimable is not None:
            estimable[start:stop] = _coef_estimable(Vh, S_inv)

        # Applying a compact operator through X.T @ y is algebraically equivalent to
        # X^+ @ y, but it behaves like a normal-equation calculation numerically and
        # can lose accuracy for severely ill-conditioned masked designs. Retain the
        # full, stable SVD pseudoinverse only for those exceptional features. This keeps
        # the common case O(F*P^2) while preserving legacy behavior where it matters.
        retained = S_inv != 0
        min_retained = np.min(np.where(retained, S, np.inf), axis=1)
        max_s = np.max(S, axis=1)
        cond = np.divide(
            max_s,
            min_retained,
            out=np.ones_like(max_s),
            where=np.isfinite(min_retained) & (min_retained > 0),
        )
        unstable = cond > max_cond
        if np.any(unstable):
            local = np.flatnonzero(unstable)
            V = np.swapaxes(Vh[local], -1, -2)
            pinv = np.einsum(
                "fpk,fk,fsk->fps", V, S_inv[local], U[local], optimize=True
            )
            illed[start] = (local, pinv)

        # U and the masked design are the large block-local arrays.
        del U, X_w, W_block

    if match_r:
        # Determine actual R-style fit failures separately from numerical rank. A
        # missing dummy level can make the masked global design rank-deficient while
        # stats::lm still succeeds after dropping that unused factor level.
        valid, rebases = _r_fit_info(dmat, missing)
        if valid is not None:
            estimable = np.broadcast_to(valid[:, None], (n_feats, n_covars))
    else:
        valid = None
        rebases = ()

    # Preserve the input precision for the response and compact-operator workspaces.
    resp = data.copy()
    np.copyto(resp, 0.0, where=missing)

    beta = np.empty((n_feats, n_covars), dtype=dtype)
    rhs = np.empty((n_covars, n_feats), dtype=dtype)
    tmp = np.empty((n_feats, n_comps), dtype=dtype)

    _apply_pinv(dmat, resp, Vh_all, S_inv_all, beta, rhs, tmp, illed)

    params = data, dmat, missing, beta, resp

    if not biased:
        theta = np.zeros(n_samps, dtype=dtype)
    elif direct:
        theta, beta = _solve_sparse_batch(
            *params, Vh_all, S_inv_all, rhs, batch, illed, valid
        )
    else:
        # Production code: full pseudoinverse
        def func(out):
            _apply_pinv(dmat, resp, Vh_all, S_inv_all, out, rhs, tmp, illed)

        theta, beta = _solve_sparse_iter(*params, func, tol, max_iter, valid)

    # See the non-batched route above. The reparameterization is feature-local and
    # preserves observed fitted values; it is needed before EM because ANCOMBC's
    # bias correction operates on the mapped coefficient slots themselves.
    if rebases:
        _r_rebase_categorical(beta, rebases, valid)

    return theta, beta, estimable, rank


def _apply_pinv(dmat, resp, Vh, S_inv, out=None, rhs=None, tmp=None, illed=None):
    """Apply feature-specific masked pseudoinverses using compact SVD operators.

    This computes coefficients for all features without materializing each complete
    pseudoinverse `X_f^+`. For feature `f`, let the masked design matrix have SVD

        X_f = U_f S_f V_f.T

    Since X_f.T y_f = V_f S_f U_f.T y_f, the coefficient estimate can be written

        beta_f = V_f S_f^-2 V_f.T (X_f.T y_f)

    The batched sparse solver therefore retains only `Vh` (`V_f.T`) and inverse
    singular values for well-conditioned features. Missing values in `resp` must
    already be replaced by zero. Ill-conditioned features may optionally be overwritten
    by stable full-SVD pseudoinverse results supplied through `illed`.

    Parameters
    ----------
    dmat : ndarray of shape (n_samples, n_covariates)
        Complete design matrix shared by all features.
    resp : ndarray of shape (n_samples, n_features)
        Responses after subtracting the current sample effects. Missing responses must
        be zero.
    Vh : ndarray of shape (n_features, n_components, n_covariates)
        Right singular vectors for each feature-specific masked design matrix, where
        `n_components = min(n_samples, n_covariates)`.
    S_inv : ndarray of shape (n_features, n_components)
        Inverse retained singular values. Singular values below the rank threshold are
        represented by zero.
    out : ndarray of shape (n_features, n_covariates), optional
        Output buffer for fitted coefficients. If omitted, a new array is allocated.
    rhs : ndarray of shape (n_covariates, n_features), optional
        Reusable workspace for the common right-hand side `dmat.T @ resp`. If
        omitted, a new array is allocated. Supplying this workspace is worthwhile in
        the iterative solver because this matrix multiplication is performed every
        iteration.
    tmp : ndarray of shape (n_features, n_components), optional
        Reusable workspace for `V_f.T (X_f.T y_f)`. If omitted, a new array is
        allocated.
    illed : dict, optional
        Stable full-SVD fallbacks for ill-conditioned features. Keys are feature-block
        starts and values are `(local_indices, pseudoinverses)`. The corresponding
        rows of `out` are overwritten after the compact calculation.

    Returns
    -------
    ndarray of shape (n_features, n_covariates)
        The fitted coefficients. This is the same object as `out` when `out` is
        provided.
    """
    n_feats = S_inv.shape[0]
    n_covars = Vh.shape[2]
    dtype = dmat.dtype
    if rhs is None:
        rhs = np.empty((n_covars, n_feats), dtype=dtype)
    if out is None:
        out = np.empty((n_feats, n_covars), dtype=dtype)
    if tmp is None:
        tmp = np.empty_like(S_inv)

    # Missing adjusted responses are already zero, so X.T @ resp is simultaneously
    # the RHS for every feature-specific masked regression.
    np.matmul(dmat.T, resp, out=rhs)

    # X_f = U S V.T and rhs = X_f.T y = V S U.T y. Therefore
    # X_f^+ y = V S^-2 V.T rhs. Retaining V and S instead of pinv(X.T X) preserves the
    # legacy SVD's rank decision and avoids forming normal equations. Reuse ``tmp`` and
    # multiply by S^-1 twice to avoid materializing ``S_inv * S_inv`` each iteration.
    np.einsum("fkp,pf->fk", Vh, rhs, out=tmp, optimize=True)
    tmp *= S_inv
    tmp *= S_inv
    np.einsum("fpk,fk->fp", np.swapaxes(Vh, -1, -2), tmp, out=out, optimize=True)

    # Stable SVD fallback
    if illed:
        for start, (local, pinv) in illed.items():
            idx = start + local
            out[idx] = np.einsum("kps,sk->kp", pinv, resp[:, idx], optimize=True)

    return out


def _solve_sparse(data, dmat, missing, beta, resp, W, dmat_inv, valid=None):
    """Solve the fully converged fixed point for zero-containing data.

    This exact method should produce numerically better result than the iterative
    optimization method. But it costs more compute due to solving a cubic system.
    """
    # The theta update is affine: theta_new = D^-1 (r + S @ theta).
    # Solve its fixed point while imposing the constraint selected by the
    # zero-initialized iteration, X.T @ D @ theta = 0.
    fitted = np.matmul(dmat, beta.T)
    np.copyto(fitted, 0.0, where=missing)
    np.subtract(data, fitted, out=resp)
    np.nan_to_num(resp, copy=False, nan=0.0)
    if valid is None:
        residual_sum = resp.sum(axis=1)
        observed_counts = missing.shape[1] - missing.sum(axis=1)
        W_fit = W
    else:
        # Match R's failed-fit behavior: invalid features have NA fitted values and are
        # omitted by ``colMeans(..., na.rm=TRUE)`` when theta is updated.
        residual_sum = np.sum(resp, axis=1, where=valid[None, :])
        observed_counts = valid.sum() - np.sum(missing, axis=1, where=valid[None, :])
        W_fit = W * valid[:, None]
    system = np.diag(observed_counts) - np.einsum(
        "fs,sp,fpt->st", W_fit, dmat, dmat_inv, optimize=True
    )
    constraint = dmat.T * observed_counts
    augmented = np.block(
        [[system, constraint.T], [constraint, np.zeros((dmat.shape[1],) * 2)]]
    )
    theta = np.linalg.lstsq(
        augmented,
        np.concatenate((residual_sum, np.zeros(dmat.shape[1]))),
        rcond=None,
    )[0][: data.shape[0]]
    np.subtract(data, theta[:, None], out=resp)
    np.copyto(resp, 0.0, where=missing)
    beta = np.einsum("fps,sf->fp", dmat_inv, resp, optimize=True)
    return theta, beta


def _solve_sparse_iter(
    data, dmat, missing, beta, resp, func, tol, max_iter, valid=None
):
    """Iterative solver for coefficients (beta) and residuals (theta).

    This process mimicks the R code. But the core step `func` can be swapped with an
    optimized path.
    """
    n_samps, n_feats = data.shape
    if valid is None:
        n_obs = n_feats - np.sum(missing, axis=1)
    else:
        # Avoid materializing an N-by-F combined mask. This branch is only active for
        # R-compatible failed fits; full-rank datasets retain the original fast path.
        n_obs = valid.sum() - np.sum(missing, axis=1, where=valid[None, :])
    theta = np.zeros(n_samps, dtype=data.dtype)

    beta_new = np.empty_like(beta)
    theta_new = np.empty_like(theta)

    epsilon = 100.0  # same as in R code
    it = 0
    while epsilon > tol and it < max_iter:
        # Adjust observed responses by the current sample effects. Missing responses
        # must be zero for both pseudoinverse routes.
        np.subtract(data, theta[:, None], out=resp)
        np.copyto(resp, 0.0, where=missing)

        # Update beta using supplied function
        func(beta_new)

        # Residuals. There is no need to clear fitted values at missing positions before
        # subtracting: ``data`` is NaN there, so the subtraction overwrites them with
        # NaN. Reduce directly into the pre-allocated theta workspace.
        np.matmul(dmat, beta_new.T, out=resp)
        np.subtract(data, resp, out=resp)
        if valid is None:
            np.nansum(resp, axis=1, out=theta_new)
        else:
            # R represents a failed feature fit by NA fitted values, which removes the
            # feature from this sample-wise mean. ``where`` reproduces that reduction
            # without writing NaNs through an N-by-F block on every iteration.
            np.nansum(resp, axis=1, where=valid[None, :], out=theta_new)
        # R's na.rm=TRUE mean is NaN when no valid feature is observed for a sample.
        # Use an explicit divide to preserve that behavior without emitting a warning.
        zero_obs = n_obs == 0
        np.divide(theta_new, n_obs, out=theta_new, where=~zero_obs)
        theta_new[zero_obs] = np.nan

        # The previous beta/theta buffers are dead once the new estimates are available.
        # Reuse them for squared convergence deltas instead of allocating F-by-P and
        # sample-length temporaries from ``(new - old) ** 2``.
        np.subtract(beta_new, beta, out=beta)
        np.square(beta, out=beta)
        np.subtract(theta_new, theta, out=theta)
        np.square(theta, out=theta)
        if valid is None:
            beta_delta = np.nansum(beta)
        else:
            # Failed R fits contain NA coefficients, so their coefficient changes are
            # omitted from the convergence criterion as well.
            beta_delta = np.sum(beta, where=valid[:, None])
        epsilon = np.sqrt(beta_delta + np.nansum(theta))

        beta, beta_new = beta_new, beta
        theta, theta_new = theta_new, theta
        it += 1

    return theta, beta


def _solve_sparse_batch(
    data, dmat, missing, beta, resp, Vh, S_inv, rhs, batch, illed, valid=None
):
    """Direct fixed-point solve using compact operators and bounded reconstruction."""
    n_samps, n_feats = data.shape
    n_covars = dmat.shape[1]

    np.matmul(dmat, beta.T, out=resp)
    np.copyto(resp, 0.0, where=missing)
    np.subtract(data, resp, out=resp)
    np.nan_to_num(resp, copy=False, nan=0.0)
    if valid is None:
        resid_sum = resp.sum(axis=1)
        n_obs = missing.shape[1] - missing.sum(axis=1)
    else:
        resid_sum = np.sum(resp, axis=1, where=valid[None, :])
        n_obs = valid.sum() - np.sum(missing, axis=1, where=valid[None, :])

    system = np.diag(n_obs.astype(np.result_type(dmat, float), copy=False))
    V = np.swapaxes(Vh, -1, -2)
    for start in range(0, n_feats, batch):
        stop = min(start + batch, n_feats)
        W_block = 1.0 - missing[:, start:stop].T
        if valid is not None:
            W_block *= valid[start:stop, None]

        # Reconstruct only this block of X_f^+ = V S^-2 V.T X_f.T. This is needed by
        # the direct sample-effect system but is discarded immediately afterwards.
        Vh_block = Vh[start:stop]
        V_block = V[start:stop]
        scaled = V_block * (S_inv[start:stop] ** 2)[:, None, :]
        gram_inv = np.matmul(scaled, Vh_block)
        xtw = dmat.T[None, :, :] * W_block[:, None, :]
        dmat_inv_block = np.matmul(gram_inv, xtw)
        if start in illed:
            local, pinv = illed[start]
            dmat_inv_block[local] = pinv
        system -= np.einsum(
            "bs,sp,bpt->st", W_block, dmat, dmat_inv_block, optimize=True
        )

    constraint = dmat.T * n_obs
    augmented = np.block(
        [[system, constraint.T], [constraint, np.zeros((n_covars,) * 2)]]
    )
    theta = np.linalg.lstsq(
        augmented,
        np.concatenate((resid_sum, np.zeros(n_covars))),
        rcond=None,
    )[0][:n_samps]

    np.subtract(data, theta[:, None], out=resp)
    np.copyto(resp, 0.0, where=missing)
    _apply_pinv(dmat, resp, Vh, S_inv, beta, rhs, None, illed)

    return theta, beta


def _calc_residual(data, dmat, beta, target_bytes=8 << 20):
    """Calculate regression residuals in-place.

    This is equivalent to `data -= dmat @ beta`, which however would materialize a
    full fitted matrix. Instead, this function multiplies feature blocks into a
    workspace of about 8 MiB to reduce memory cost while retaining efficient matrix
    multiplication.
    """
    n_samps, n_feats = data.shape
    if n_feats == 0:
        return

    cols = max(1, target_bytes // max(data.itemsize * n_samps, 1))
    cols = min(cols, n_feats)
    fitted = np.empty((n_samps, cols), dtype=data.dtype)

    for start in range(0, n_feats, cols):
        stop = min(start + cols, n_feats)
        block = fitted[:, : stop - start]
        np.matmul(dmat, beta[:, start:stop], out=block)
        data[:, start:stop] -= block


def _lstsq_dense(dmat, gram=False):
    """Calculate a least-squares operator and optional inverse-Gram sum vector.

    Both operators are derived from one singular value decomposition.
    """
    U, S, Vh = np.linalg.svd(dmat, full_matrices=False)
    S_inv = _invert_singular(S)
    V = Vh.T
    dmat_inv = (V * S_inv) @ U.T
    if gram:
        # Calculate a sum vector of inverse Gram matrix
        gram_sum = V @ ((S_inv**2) * np.sum(Vh, axis=1))
        # If one needs the full inverse Gram matrix, it is:
        # gmat_inv = (V * S_inv**2) @ Vh
    else:
        gram_sum = None
    return dmat_inv, gram_sum


def _r_fit_info(dmat, missing):
    """Identify R-style failed fits and feature-local categorical references.

    R rebuilds each feature's model frame after omitting zero-derived ``NA``
    responses. A categorical predictor with fewer than two observed levels makes
    ``lm`` fail at contrast construction. If two or more levels remain but the
    original reference level is absent, treatment coding instead chooses the first
    remaining level as a feature-local reference. ANCOMBC maps that local coefficient
    vector back into the global coefficient slots, filling omitted slots with zero.

    This helper reproduces those two behaviors for categorical *main effects* encoded
    by Patsy's ordinary reduced-rank treatment contrast. Multiple additive categorical
    terms are supported. Factors that participate in interactions are still checked
    for whole-fit failure, but are intentionally not rebased here: changing a
    reference level also changes the associated interaction basis, which cannot be
    represented by a safe main-effect-only column operation.

    Returns
    -------
    valid : ndarray of bool or None
        Feature-level fit validity. ``None`` is the all-valid fast-path sentinel.
    rebases : tuple
        Compact instructions consumed by :func:`_r_rebase_categorical`.
    """
    info = getattr(dmat, "design_info", None)
    if info is None:
        return None, ()

    n_samps, n_feats = missing.shape
    # lm also fails when zero omission leaves no response at all.
    valid = np.sum(missing, axis=0) < n_samps
    checked = not np.all(valid)
    rebases = []

    try:
        intercept = info.column_names.index("Intercept")
    except ValueError:
        intercept = None

    for factor, factor_info in info.factor_infos.items():
        if factor_info.type != "categorical":
            continue

        # Ordinary hierarchical formulas (including ``a * b``) contain a standalone
        # main-effect term whose contrast rows identify the factor levels.
        term = next(
            (t for t in info.terms if len(t.factors) == 1 and t.factors[0] == factor),
            None,
        )
        if term is None:
            continue

        sl = info.term_slices[term]
        codes = np.asarray(dmat[:, sl])
        codings = info.term_codings.get(term, ())
        contrast = None
        if len(codings) == 1:
            contrast_obj = codings[0].contrast_matrices.get(factor)
            if contrast_obj is not None:
                contrast = np.asarray(contrast_obj.matrix)

        # Prefer Patsy's contrast matrix because it preserves category order and tells
        # us which row is the reference. Fall back to unique design rows when a custom
        # coding cannot be interpreted; the fallback is enough for fit-failure
        # detection but deliberately does not attempt reference rebasing.
        standard_treatment = False
        if (
            contrast is not None
            and contrast.shape[1] == sl.stop - sl.start
            and contrast.shape[0] == len(factor_info.categories)
            and contrast.shape[1] == contrast.shape[0] - 1
        ):
            zero_rows = np.flatnonzero(np.all(contrast == 0, axis=1))
            nonzero = (
                np.delete(contrast, zero_rows, axis=0) if zero_rows.size == 1 else None
            )
            standard_treatment = (
                zero_rows.size == 1
                and nonzero is not None
                and np.all((nonzero == 0) | (nonzero == 1))
                and np.all(np.sum(nonzero, axis=1) == 1)
                and np.array_equal(
                    np.sort(np.argmax(nonzero, axis=1)),
                    np.arange(contrast.shape[1]),
                )
            )

        if standard_treatment:
            ref_level = int(zero_rows[0])
            # Map each factor level to its main-effect design column (-1 for reference).
            level_col = np.full(contrast.shape[0], -1, dtype=np.intp)
            for level_idx in range(contrast.shape[0]):
                if level_idx != ref_level:
                    level_col[level_idx] = int(np.argmax(contrast[level_idx]))

            present = np.zeros((n_feats, contrast.shape[0]), dtype=bool)
            level_missing = np.empty(n_feats, dtype=np.intp)
            for level_idx, col in enumerate(level_col):
                if col < 0:
                    rows = np.all(codes == 0, axis=1)
                else:
                    rows = codes[:, col] == 1
                np.sum(
                    missing,
                    axis=0,
                    where=rows[:, None],
                    dtype=np.intp,
                    out=level_missing,
                )
                present[:, level_idx] = level_missing < rows.sum()

            valid &= np.sum(present, axis=1) >= 2
            checked = True

            # With an intercept and a treatment-coded additive main effect, changing
            # the reference is a cheap null-space reparameterization. Do not apply it
            # to factors used in interactions: their interaction columns must be
            # transformed together, and silently changing only the main effect would
            # alter fitted values.
            in_interaction = any(
                factor in t.factors and len(t.factors) > 1 for t in info.terms
            )
            if intercept is not None and not in_interaction:
                needs = ~present[:, ref_level]
                if np.any(needs):
                    local_ref = np.full(n_feats, -1, dtype=np.intp)
                    # Patsy orders the categories in ``factor_info.categories``; after
                    # dropping the missing global reference, the first remaining level
                    # becomes the local treatment reference.
                    for level_idx, col in enumerate(level_col):
                        if level_idx == ref_level:
                            continue
                        choose = needs & (local_ref < 0) & present[:, level_idx]
                        local_ref[choose] = col
                    rows = np.flatnonzero(local_ref >= 0)
                    if rows.size:
                        # Keep presence only for the affected rows and non-reference
                        # dummy columns. This is tiny compared with the SVD workspaces.
                        dummy_present = np.empty((rows.size, sl.stop - sl.start), bool)
                        for level_idx, col in enumerate(level_col):
                            if col >= 0:
                                dummy_present[:, col] = present[rows, level_idx]
                        rebases.append(
                            (
                                intercept,
                                sl.start,
                                sl.stop,
                                rows,
                                local_ref[rows].copy(),
                                dummy_present,
                            )
                        )
        else:
            # Custom/full-rank contrast: retain the previous conservative failure
            # check based on distinct factor-code rows, but do not guess how Patsy
            # should reparameterize its coefficients.
            _, level = np.unique(codes, axis=0, return_inverse=True)
            n_levels = int(level.max()) + 1
            if n_levels < 2:
                valid[:] = False
                checked = True
                break
            observed_levels = np.zeros(n_feats, dtype=np.intp)
            level_missing = np.empty(n_feats, dtype=np.intp)
            for i in range(n_levels):
                rows = level == i
                np.sum(
                    missing,
                    axis=0,
                    where=rows[:, None],
                    dtype=np.intp,
                    out=level_missing,
                )
                observed_levels += level_missing < rows.sum()
            valid &= observed_levels >= 2
            checked = True

    valid_out = None if not checked or np.all(valid) else valid
    return valid_out, tuple(rebases)


def _r_rebase_categorical(beta, rebases, valid=None):
    """Map treatment-coded sparse fits to feature-local reference levels in place.

    The Moore-Penrose solution and R's local treatment-coded solution have identical
    fitted values on observed samples; they differ only by a null-space component when
    the global reference level is absent. ANCOMBC's EM step operates on coefficient
    slots, so matching that representation matters even though predictions are
    unchanged.
    """
    for intercept, start, stop, rows, local_ref, present in rebases:
        if valid is not None:
            keep = valid[rows]
            if not np.any(keep):
                continue
            rows = rows[keep]
            local_ref = local_ref[keep]
            present = present[keep]

        cols = start + local_ref
        shift = beta[rows, cols].copy()
        beta[rows, intercept] += shift

        # Omitted non-reference levels are zero-filled by ANCOMBC rather than shifted.
        block = beta[np.ix_(rows, np.arange(start, stop))]
        block -= shift[:, None] * present
        block[~present] = 0.0
        beta[np.ix_(rows, np.arange(start, stop))] = block
        # Make the feature-local reference exact rather than relying on subtraction
        # roundoff; this is also how ANCOMBC's zero-filled global slot appears.
        beta[rows, cols] = 0.0


def _coef_estimable(Vh, S_inv):
    """Identify uniquely estimable coefficients from a masked-design SVD.

    The retained right singular vectors span the row space of the design matrix. A
    coefficient ``beta_j`` is identifiable exactly when the coordinate vector ``e_j``
    lies in that row space. For an orthogonal projector, this is equivalent to the
    corresponding diagonal of ``V_r @ V_r.T`` being one.
    """
    retained = S_inv != 0
    proj_diag = np.einsum("fkp,fk,fkp->fp", Vh, retained, Vh, optimize=True)
    # Scale the tolerance with machine precision so float32 and float64 make the same
    # conceptual rank decision without requiring an unnecessarily loose fixed epsilon.
    atol = 100.0 * np.finfo(Vh.dtype).eps
    return proj_diag >= 1.0 - atol


def _invert_singular(S):
    """Invert significant singular values.

    The Gram matrix may be singular, if there are colinear covariates in the design
    matrix. In such cases, a direct `inv` will raise an error, and `pinv` (Moore-Penrose
    pseudoinverse)is the robust choice.

    Small singular values are set to zero prior to inversion. The process and threshold
    (1e-15) are consistent with the underlying algorithm of `pinv`.
    """
    cutoff = 1e-15 * np.max(S, axis=-1, keepdims=True)
    return np.divide(1.0, S, out=np.zeros_like(S), where=S > cutoff)


def _calc_grouped_var_cov(res2, hmat, groups):
    """Calculate variances and covariance matrix of coefficients.

    Parameters
    ----------
    res2 : ndarray of shape (n_samples, n_features)
        Squared, centered residuals. Any float type. Missing values must already be
        replaced with zero.
    hmat : ndarray of shape (n_samples, n_covariates)
        Influence matrix H. The same float type as `res2`.
    groups : ndarray of shape (n_groups - 1,), bool, or None
        Indices of coefficients representing groups.

    Returns
    -------
    var_hat : ndarray of shape (n_features, n_covariates)
        Estimated variances of regression coefficients.
    covmat : ndarray or None
        Estimated covariance matrices of coefficients.
    """
    if groups is True:
        covmat = _calc_covariance(res2, hmat)
        var_hat = np.diagonal(covmat, axis1=1, axis2=2)
        # Make a writable F-contiguous copy of the read-only diagonal view.
        var_hat = np.asfortranarray(var_hat)
    elif groups is not None:
        var_hat, covmat = _calc_var_cov(res2, hmat, groups)
    else:
        var_hat = _calc_variance(res2, hmat)
        covmat = None
    return var_hat, covmat


def _calc_variance(res2, hmat):
    """Calculate coefficient variances without forming full covariance matrices.

    For feature i, there is:

        diag(Cov(beta_i)) = sum_j resid_sq[j, i] * influence[j]**2

    This is a single matrix multiplication with an (n_features, n_covariates) output.

    This function outputs an F-contiguous array. Otherwise, it can be replaced with:

        `return resid_sq.T @ influence**2`
    """
    var_hat = np.empty((res2.shape[1], hmat.shape[1]), dtype=res2.dtype, order="F")
    np.matmul(res2.T, np.square(hmat), out=var_hat)
    return var_hat


def _calc_covariance(res2, hmat):
    """Calculate full covariance matrices.

    For feature i, the covariance is:

        Cov(beta_i) = sum_j resid2_ji * h_j h_j.T

    where H = X @ (X.T @ X)^+ is the influence matrix (^+ means Moore-Penrose
    pseudoinverse). This H is given by `dmat_inv.T` calculated upstream.

    Flattening h_j h_j.T turns the contraction over samples into one matrix
    multiplication across all features.
    """
    n_samps, n_covars = hmat.shape
    prods = (hmat[:, :, None] * hmat[:, None, :]).reshape(n_samps, n_covars * n_covars)
    return (res2.T @ prods).reshape(res2.shape[1], n_covars, n_covars)


def _calc_var_cov(res2, hmat, groups):
    """Calculate all variances and one symmetric covariance submatrix.

    All coefficient variances are calculated through `_calc_variance`, exactly the same
    path used when no grouping is requested. This guarantees that enabling post-hoc
    analysis does not perturb the primary result.

    A second, smaller matrix multiplication calculates only the k * (k - 1) / 2 unique
    off-diagonal covariances needed by the selected grouping, avoiding calculating the
    full covariance matrix.
    """
    n_samps, n_covars = hmat.shape
    n_feats = res2.shape[1]
    k = groups.size

    # Keep the primary variances bit-for-bit on the same calculation path regardless
    # of whether a grouping was requested.
    var_hat = _calc_variance(res2, hmat)
    covmat = np.empty((n_feats, k, k), dtype=var_hat.dtype)
    diag_idx = np.arange(k)
    covmat[:, diag_idx, diag_idx] = var_hat[:, groups]

    # Calculate off-diagonal covariances if needed
    i, j = np.triu_indices(k, 1)
    if i.size > 0:
        covmat[:, i, j] = covmat[:, j, i] = np.einsum(
            "sf,si,si->fi", res2, hmat[:, groups[i]], hmat[:, groups[j]], optimize=True
        )

    return var_hat, covmat


# Numerical optimization setting for sampling bias estimation through an Expectation-
# maximization (EM) algorithm.
#
# The Nelder-Mead simplex algorithm is used, to be consistent with the R code. Note: It
# does not actually enforce bounds during optimization. Rather, it merely clips at the
# bounds. Noted for further consideration.
#
# Tighter convergence tolerance produce more precise estimates in each EM step, leading
# to smaller accumulated errors. SciPy's default is 1e-4, which would produce different
# results from the R code. The value 1e-8 was selected according to our benchmarks.
OPTARG = dict(
    method="Nelder-Mead",
    bounds=[(0, None)],
    options={"xatol": 1e-8, "fatol": 1e-8},
)


def _estimate_bias_em(beta, var_hat, tol=1e-5, max_iter=100):
    """Estimate sampling bias through an expectation-maximization (EM) algorithm.

    This function models the observed coefficients (log-fold changes) for a given
    covariate as a Gaussian mixture distribution with three components: 0) null,
    1) negative, 2) positive. It aims to estimate a global bias term (delta) that
    affects all features.

    Parameters
    ----------
    beta : ndarray of shape (n_features,)
        Estimated coefficients (log-fold change before correction).
    var_hat : ndarray of shape (n_features,)
        Estimated variances of regression coefficients.
    tol : float, optional
        Absolute tolerance of EM iteration. Default is 1e-5.
    max_iter : int
        Max number of iteration of EM iteration. Default is 100.

    Returns
    -------
    delta_em : float
        EM estimator of bias.
    delta_wls : float
        WLS estimator of bias.
    var_delta : float
        Estimated variances of bias.

    """
    # This function involves careful memory optimization to avoid creating temporary
    # arrays during iteration. Technically, the arrays could have been pre-allocated
    # in the outer function `_ancombc_core` and re-used across covariates, which could
    # further enhance memory efficiency. It is left as-is for modularity.
    dtype = beta.dtype

    # The original R code has `na.rm = TRUE` in many commands. This is not necessary
    # in the current implementation, because the pre-correction coefficients (beta)
    # is guaranteed to not contain NaN values.
    # Mask NaN values (deemed unnecessary; left here for future examination).
    # beta = beta[~np.isnan(beta)]

    # There might be a chance that numeric optimization produces (near) zero weights
    # (pi) or variances (kappa), which can cause numerical stability issues in the
    # EM process. To safe-guard, one may use a small number `eps` as the floor of
    # those parameters. The original R code doesn't have this mechanism. Therefore, it
    # is currently disabled.
    # eps = 1e-12

    # Initial model parameters
    pi0, pi1, pi2 = 0.75, 0.125, 0.125  # weights of components (pi)
    delta, l1, l2, kappa1, kappa2 = _init_bias_params(beta)
    params = np.array([pi0, pi1, pi2, delta, l1, l2, kappa1, kappa2], dtype=dtype)
    updated = np.empty(8, dtype=dtype)

    # Pre-allocate memory for intermediates. Each array has three rows, representing
    # the three components (0, 1, 2), and columns representing individual features.
    # Let delta_i = mu_i1_hat - mu_i2_hat
    # The distribution of delta_i is modeled by Gaussian mixture:
    # f(delta_i) = pi0 * phi((delta_i - delta) / nu_i0) +
    #              pi1 * phi((delta_i - (delta + l1)) / nu_i1) +
    #              pi2 * phi((delta_i - (delta + l2)) / nu_i2)
    # where phi is the normal density function,
    # (delta + l1) and (delta + l2) are means for delta_i | C1 and delta_i | C2
    # nu_i0, nu_i1, and nu_i2 are variances of delta_i | C0, delta_i | C1, and
    # delta_i | C2 respectively.
    # We assume nu_i1 = nu_i0 + kappa1 and nu_i2 = nu_i0 + kappa2 for computational
    # simplicity.
    n_feats = beta.shape[0]
    shape = (3, n_feats)
    nu_inv = np.empty(shape, dtype=dtype)  # inverse of variances
    sd_inv = np.empty(shape, dtype=dtype)  # inverse of standard deviations
    ratios = np.empty(shape, dtype=dtype)  # coefficients / variances

    # Mean coefficients
    means = np.empty(3, dtype=dtype)

    # Posterior probabilities of feature-component assignments (EM's responsibilities)
    resp = np.empty(shape, dtype=dtype)

    # Just a 2-row array to store random data
    intm = np.empty((2, n_feats), dtype=dtype)
    intm0, intm1 = intm

    # Initialize intermediates. The 1st row is constant, representing pre-correction
    # estimates, whereas the 2nd and 3rd rows are to be modified during iteration.
    # NOTE: Making `var_hat` C-contiguous can further improve performance, but this is
    # marginal compared with the EM process.
    np.reciprocal(var_hat, out=nu_inv[0])
    np.sqrt(nu_inv[0], out=sd_inv[0])
    np.divide(beta, var_hat, out=ratios[0])

    # Objective function for optimization of variance estimation. For fixed `loc` and
    # responsibilities, the negative weighted Gaussian log-likelihood is, up to an
    # additive constant:
    #   0.5 * sum(resp * ((beta - loc)**2 / (var_hat + x) + log(var_hat + x)))
    # The omitted 0.5 * log(2 * pi) * sum(resp) term is independent of `x` and
    # therefore cannot affect the minimizer. The squared residual `(beta - loc)**2`
    # is also independent of `x`; it is computed once per component below and passed
    # into this callback, instead of being recomputed at every Nelder-Mead evaluation.
    # The factor 0.5 is retained because `OPTARG` uses an absolute function tolerance
    # (`fatol`); dropping the factor would rescale the stopping criterion.
    def func(x, sq_diff, resp):
        np.add(var_hat, x[0], out=intm0)
        np.log(intm0, out=intm1)
        np.divide(sq_diff, intm0, out=intm0)
        np.add(intm0, intm1, out=intm0)
        return 0.5 * np.dot(resp, intm0)

    # Expectation-maximization (E-M) iterations
    loss, it = np.inf, 0
    while loss > tol and it < max_iter:
        # Update intermediates (2nd and 3rd rows only)
        np.add(var_hat, params[6:8, None], out=intm)  # kappa1, kappa2
        np.reciprocal(intm, out=nu_inv[1:])
        np.sqrt(nu_inv[1:], out=sd_inv[1:])
        np.subtract(beta, params[4:6, None], out=ratios[1:])  # means (l)
        ratios[1:] *= nu_inv[1:]

        ### E-step ###
        # Mean coefficients
        delta = means[0] = params[3]  # global bias (delta)
        np.add(params[4:6], delta, means[1:])

        # Posterior probabilities = Gaussian densities weighted by component fractions.
        # The normalizing constant 1 / sqrt(2 * pi) is shared by all components and
        # cancels when responsibilities are normalized, so it is omitted. Compute the
        # remaining density directly in pre-allocated memory:
        #   exp(-0.5 * (beta - mean_r)**2 / nu_r) / sqrt(nu_r)
        # where `nu_inv` is 1 / nu_r and `inv_stdevs` is 1 / sqrt(nu_r).
        np.subtract(beta, means[:, None], out=resp)
        np.square(resp, out=resp)
        resp *= nu_inv
        resp *= -0.5
        np.exp(resp, out=resp)
        resp *= sd_inv
        resp *= params[:3, None]  # weights (pi)
        resp /= np.sum(resp, axis=0, keepdims=True)

        ### M-step ###
        # Weights of components (pi)
        # pi_r_new = mean(pi_r * pdf_r / (pi0 * pdf0 + pi1 * pdf1 + pi2 * pdf2)),
        # where r = 0, 1, 2
        np.mean(resp, axis=1, out=updated[:3])

        # Avoid zero weights.
        # updated[:3] = np.maximum(updated[:3], eps)
        # updated[:3] /= updated[:3].sum()

        # Gaussian mixture modeling of global bias (delta)
        # The following code produces the same result as:
        #   updated[3] = np.sum(resp * ratios) / np.sum(resp * nu_inv)
        # But it avoids creating intermediate arrays.
        # delta_new = sum(r_0i * beta / nu0 +
        #                 r_1i * (beta - l1) / (nu0 + kappa1) +
        #                 r_2i * (beta - l2) / (nu0 + kappa2)) /
        #             sum(r0i / nu0 + r1i / (nu0 + kappa1) + r2i / (nu0 + kappa2))
        updated[3] = np.vdot(resp, ratios) / np.vdot(resp, nu_inv)

        # Negative and positive components relative to delta (l)
        np.multiply(resp[1:], nu_inv[1:], out=intm)
        denom = np.sum(intm, axis=1)
        np.subtract(beta, delta, out=resp[0])  # reuse as intermediate
        intm *= resp[0]
        numer = np.sum(intm, axis=1)
        l1, l2 = numer / denom
        # l1_new = min(sum(r1i * (beta - delta) / (nu0 + kappa1)) /
        #              sum(r1i / (nu0 + kappa1)), 0)
        updated[4] = np.minimum(l1, 0)
        # l2_new = min(sum(r2i * (beta - delta) / (nu0 + kappa2)) /
        #              sum(r2i / (nu0 + kappa2)), 0)
        updated[5] = np.maximum(l2, 0)

        # Perform numeric optimization to minimize variances of negative and positive
        # components (kappa). The component means and responsibilities stay fixed
        # throughout each M-step optimization, so precompute squared residuals once.
        # `ratios[1:]` is no longer needed after the delta update above and is reused
        # here as workspace.
        np.subtract(beta, means[1:, None], out=ratios[1:])
        np.square(ratios[1:], out=ratios[1:])

        # TODO: Consider scenarios where optimization doesn't converge.
        updated[6] = minimize(func, params[6], args=(ratios[1], resp[1]), **OPTARG).x[0]
        updated[7] = minimize(func, params[7], args=(ratios[2], resp[2]), **OPTARG).x[0]

        # Avoid zero variances.
        # updated[6] = max(updated[6], eps)
        # updated[7] = max(updated[7], eps)

        # Loss (epsilon)
        # epsilon = sqrt((pi0_new - pi0)^2 + (pi1_new - pi1)^2 + (pi2_new - pi2)^2 +
        #                (delta_new - delta)^2 + (l1_new - l1)^2 + (l2_new - l2)^2 +
        #                (kappa1_new - kappa1)^2 + (kappa2_new - kappa2)^2)
        loss = np.linalg.norm(updated - params)

        params[:] = updated
        it += 1

    return _estimate_bias_var(beta, var_hat, params)


def _init_bias_params(beta):
    """Initialize parameters for iterative bias estimation.

    Parameters
    ----------
    beta : ndarray of shape (n_features,)
        Estimated coefficients before correction.

    Returns
    -------
    delta : float
        Initial global bias term.
    l1, l2 : float
        Initial means of negative and positive components, respectively.
    kappa1, kappa2 : float
        Initial variances of negative and positive components, respectively.

    """
    edges = np.quantile(beta, (0.125, 0.25, 0.75, 0.875))

    # Estimate delta (mean of values between q1 and q3)
    if np.any(mask := (beta >= edges[1]) & (beta <= edges[2])):
        delta = np.mean(beta[mask])
    else:
        delta = np.mean(beta)

    # Estimate l1
    if np.any(mask := beta < edges[0]):
        l1 = np.mean(beta_ := beta[mask])
        if beta_.size > 1:
            kappa1 = np.var(beta_, ddof=1, mean=l1) or 1.0
        else:
            kappa1 = 1.0
    else:
        l1 = np.min(beta)
        kappa1 = 1.0

    # Estimate l2
    if np.any(mask := beta > edges[3]):
        l2 = np.mean(beta_ := beta[mask])
        if beta_.size > 1:
            kappa2 = np.var(beta_, ddof=1, mean=l2) or 1.0
        else:
            kappa2 = 1.0
    else:
        l2 = np.max(beta)
        kappa2 = 1.0

    return delta, l1, l2, kappa1, kappa2


def _estimate_bias_var(beta, var_hat, params):
    """Estimate variance of sampling bias according to EM-optimized parameters.

    This function calculates the weighted least squares (WLS) estimator of bias.

    Parameters
    ----------
    beta : ndarray of shape (n_features,)
        Estimated coefficients (log-fold change before correction).
    var_hat : ndarray of shape (n_features,)
        Estimated variances of regression coefficients.
    params : ndarray of shape (8,)
        Model parameters optimized by EM.

    Returns
    -------
    delta_em : float
        EM estimator of bias.
    delta_wls : float
        WLS estimator of bias.
    var_delta : float
        Estimated variance of bias.

    """
    pi0, pi1, pi2, delta, l1, l2, kappa1, kappa2 = params

    # The EM estimator of bias
    delta_em = delta

    # Assign features to Gaussian components (C)
    q1, q2 = np.quantile(beta, (pi1, 1.0 - pi2))
    C1 = np.flatnonzero(beta < q1)
    C2 = np.flatnonzero(beta >= q2)

    # Numerator of the WLS estimator
    nu_inv = var_hat.copy()
    nu_inv[C1] += kappa1
    nu_inv[C2] += kappa2
    nu_inv[:] = 1.0 / nu_inv
    wls_denom = np.sum(nu_inv)

    # Denominator of the WLS estimator
    beta_ = beta.copy()
    beta_[C1] -= l1
    beta_[C2] -= l2
    nu_inv *= beta_
    wls_numer = np.sum(nu_inv)

    # Estimate the variance of bias
    wls_denom_inv = 1.0 / wls_denom
    delta_wls = wls_numer * wls_denom_inv
    var_delta = np.nan_to_num(wls_denom_inv)

    return delta_em, delta_wls, var_delta


def _sample_fractions(
    data, dmat, beta, delta_em, missing=None, estimable=None, match_r=False
):
    """Estimate sampling fractions.

    Parameters
    ----------
    data : ndarray of shape (n_samples, n_features)
        Data table. Zero-handled. Transformed.
    dmat : ndarray of shape (n_samples, n_covariates)
        Design matrix.
    beta : ndarray of shape (n_covariates, n_features)
        Estimated coefficients.
    delta_em : ndarray of shape (n_covariates,)
        Estimated biases.
    missing : ndarray of shape (n_samples, n_features), optional
        Boolean mask of unobserved entries. When absent, use an algebraically equivalent
        dense calculation that avoids an n_samples x n_features residual array.
    estimable : ndarray of bool of shape (n_features, n_covariates), optional
        Inferential estimability mask from the initial sparse fit.
    match_r : bool, optional
        If True, features whose R-style fit failed contribute zero fitted value when
        sampling fractions are formed.

    Returns
    -------
    theta_hat : ndarray of shape (n_covariates,)
        Estimated sampling fractions.

    """
    # Compute sampling fractions. For dense data, linearity of the mean gives:
    #   mean(data - X @ beta + X @ delta, axis=features)
    #     = mean(data) - X @ mean(beta) + X @ delta,
    # avoiding another n_samples x n_features matrix while `data` must remain intact.
    if missing is None:
        theta_hat = np.mean(data, axis=1)
        theta_hat -= dmat @ np.mean(beta, axis=1)
        theta_hat += dmat @ delta_em

    # R's post-EM sampling-fraction calculation treats all-NA coefficients from a
    # failed per-feature lm fit as contributing zero fitted value (rowSums(...,
    # na.rm=TRUE)). Reproduce this in match-R mode, otherwise keep the Moore-Penrose
    # fitted values.
    else:
        if match_r and estimable is not None:
            valid = np.all(estimable, axis=1)
            beta_work = beta.copy()
            beta_work[:, ~valid] = 0.0
            intm = dmat @ beta_work
            # The bias correction is likewise absent for a failed fit because NA -
            # delta remains NA in R and is ignored by rowSums(na.rm=TRUE).
            intm -= (dmat @ delta_em)[:, None] * valid[None, :]
        else:
            intm = dmat @ beta
            intm -= (dmat @ delta_em)[:, None]
        intm -= data
        intm *= -1.0
        theta_hat = np.nanmean(intm, axis=1)

    return theta_hat


def _adjust_variance(var_hat, vcov_hat, var_delta, var_quantile, groups=None):
    """Adjust variances.

    Parameters
    ----------
    var_hat : ndarray of shape (n_features, n_covariates)
        Estimated variances.
    vcov_hat : ndarray or None
        Full coefficient covariance matrices or a retained covariance submatrix. May be
        None when only coefficient variances were requested.
    var_delta : ndarray of shape (n_covariates,)
        Estimated variances of biases.
    var_quantile : float
        Quantile of coefficient variances used to calculate a variance-stabilizing
        offset. Set to 0 to disable.
    groups : 1-D array_like of int, optional
        Full-model coefficient indices represented by ``vcov_hat`` when it is a
        covariance submatrix.

    Notes
    -----
    This function updates `var_hat` and `vcov_hat` (if provided), and overwrites
    `var_delta` in place.
    """
    # var = var + delta + 2 * |var * delta|^0.5 = (var^0.5 + delta^0.5)^2
    np.sqrt(var_hat, out=var_hat)
    np.sqrt(var_delta, out=var_delta)
    var_hat += var_delta[None, :]
    np.square(var_hat, out=var_hat)

    # Add a variance-stabilizing offset based on the requested quantile.
    # The space of `var_delta` is reused to store the offset.
    if var_quantile:
        np.nanquantile(var_hat, var_quantile, axis=0, out=var_delta)
        var_hat += var_delta[None, :]

    # Keep a retained covariance tensor consistent with the adjusted variances.
    if vcov_hat is not None:
        if groups is None:
            diag = np.arange(var_hat.shape[1])
            vcov_hat[:, diag, diag] = var_hat
        else:
            diag = np.arange(groups.size)
            vcov_hat[:, diag, diag] = var_hat[:, groups]


def _calc_statistics(
    beta_hat, var_hat, alpha, p_adjust, dof=None, estimable=None, inplace=False
):
    """Calculate primary statistics, including estimability masking.

    Parameters
    ----------
    beta_hat : ndarray of shape (n_features, n_covariates)
        Estimated coefficients post correction.
    var_hat : ndarray of shape (n_features, n_covariates)
        Estimated variances.
    alpha : float
        Significance level.
    p_adjust : str
        Multiple testing correction method.
    dof : float or ndarray of shape (n_features,), optional
        Degrees of freedom.
    estimable : ndarray of bool of shape (n_features, n_covariates), optional
        Whether each coefficient is uniquely identifiable. Non-estimable coefficients
        are reported with NaN estimates/statistics and unit p- and q-values.
    inplace : bool, optional
        If True, reuse `beta_hat` and `var_hat` for the returned coefficients and
        standard errors, including estimability masking. Default is False.

    Returns
    -------
    lfc : ndarray of shape (n_features, n_covariates)
        Estimated coefficients (log(FC)).
    se : ndarray of shape (n_features, n_covariates)
        Estimated standard errors.
    W : ndarray of shape (n_features, n_covariates)
        Test statistics.
    pval : ndarray of shape (n_features, n_covariates)
        p-values.
    qval : ndarray of shape (n_features, n_covariates)
        Adjusted p-values.
    reject : ndarray of shape (n_features, n_covariates)
        Significant differential abundance (reject null hypothesis).

    Notes
    -----
    Each returned array has independent storage so it can be passed to pandas with
    `copy=False` without later calculations changing an already constructed column.
    """
    lfc = beta_hat if inplace else beta_hat.copy()
    if estimable is not None:
        non_estimable = ~estimable
        lfc[non_estimable] = np.nan

    # Standard error = sqrt(variance)
    se = np.sqrt(var_hat, out=var_hat if inplace else None)
    if estimable is not None:
        se[non_estimable] = np.nan

    # Test statistic W = coef / s.e.
    W = lfc / se

    # p-values (calculated by t-test or Z-test)
    # Non-estimables are set to 1, following R.
    pval = _calc_pvalues(W, dof)
    if estimable is not None:
        pval[non_estimable] = 1.0

    # Adjust p-values
    qval = _adjust_pvalues(pval, p_adjust)
    reject = qval <= alpha

    return lfc, se, W, pval, qval, reject


def _calc_pvalues(W, dof=None):
    """Calculate p-values from test statistics (W).

    p-values are calculated using t-test (with degrees of freedom (dof) provided, as in
    ANCOM-BC2) or Z-test (without dof, as in ANCOM-BC).

    Parameters
    ----------
    W : ndarray of shape (n_features, n_covariates)
        Test statistics.
    dof : float or ndarray of shape (n_features,), optional
        Degrees of freedom.

    Returns
    -------
    pval : ndarray of shape (n_features, n_covariates)
        p-values.

    """
    W_abs = np.abs(W)
    if dof is not None:  # t-test with dof
        if not np.isscalar(dof):
            dof = np.asarray(dof)[:, None]  # broadcast to 2D
        pval = t.sf(W_abs, dof)
    else:  # Z-test
        pval = norm.sf(W_abs)
    pval *= 2.0  # two-sided test
    return pval


class ANCOMBCResult:
    r"""Results for ANCOM-BC and ANCOM-BC2 analyses.

    This class contains the primary differential abundance results. The object displays
    as the primary result table and supports ``[]`` selection like a pandas DataFrame.
    The underlying DataFrame is available through :attr:`result`. Post-hoc analyses are
    available as methods that compute on-demand when a ``grouping`` was specified in
    the upstream :func:`ancombc` or :func:`ancombc2` call.

    The primary result table has a (FeatureID, Covariate) multi-index. The index levels
    and columns are:

    - ``FeatureID``: Feature identifier, i.e., dependent variable.

    - ``Covariate``: Covariate name, i.e., independent variable.

    - ``Log(FC)``: Estimated model coefficient representing natural-log-fold change of
      abundance from the reference category to the covariate category defined in the
      formula. NaN indicates that the value is not estimable from the observed data.

    - ``SE``: Standard error of the estimated coefficient, or NaN if not estimable.

    - ``W``: *W*-statistic, calculated as the estimated coefficient value divided by
      its standard error.

    - ``pvalue``: Uncorrected *p*-value of the *W*-statistic.

    - ``qvalue``: *p*-value corrected for multiple testing.

    - ``Signif``: Whether the covariate category is significantly differentially
      abundant from the reference category. A feature-covariate pair is marked as
      "True" if the *q*-value is less than or equal to the significance level.

    See Also
    --------
    ancombc : ANCOM-BC function.
    ancombc2 : ANCOM-BC2 function.
    """

    _private_defaults = {
        "_dmat": None,
        "_groups": None,
        "_beta_hat": None,
        "_var_hat": None,
        "_vcov_hat": None,
        "_dof": None,
        "_estimable": None,
        "_features": None,
        "_covariates": None,
        "_alpha": 0.05,
        "_p_adjust": "holm",
        "_var_quantile": 0.05,
        "_max_iter": 100,
        "_tol": 1e-5,
        "_pseudo": 0,
        "_global_cache": None,
    }

    def __init__(self, result: pd.DataFrame, method: str, **kwargs):
        self._result = result
        self._method = method
        for name, default in self._private_defaults.items():
            setattr(self, name, kwargs.get(name, default))

    @property
    def result(self) -> pd.DataFrame:
        """Primary differential abundance result table."""
        return self._result

    def __getitem__(self, key):
        """Select columns or rows from the primary result table."""
        return self._result[key]

    def __repr__(self):
        """Display the primary result table."""
        return repr(self._result)

    def _repr_html_(self):
        """Display the primary result table in rich notebook frontends."""
        return self._result._repr_html_()

    def _require_groups(self, method):
        """Require an upstream grouping for post-hoc analyses."""
        if self._groups is None:
            raise ValueError(
                f"`{method}` requires a post-hoc grouping. Rerun the function with "
                "`grouping` specified to enable post-hoc analysis."
            )

    def _stat_params(self, alpha, p_adjust):
        """Get FDR-correction method and significance level from upstream."""
        if alpha == "inherit":
            alpha = self._alpha
        if p_adjust == "inherit":
            p_adjust = self._p_adjust
        return alpha, p_adjust

    def _posthoc_estimable(self):
        """Return feature-level estimability for the selected grouping term."""
        if self._estimable is None:
            return None
        valid = np.all(self._estimable[:, self._groups], axis=1)
        return None if np.all(valid) else valid

    def _get_global_stats(self):
        """Lazily cache statistics independent of alpha and p-value adjustment."""
        if self._global_cache is None:
            self._global_cache = _global_stats(
                self._groups,
                self._beta_hat,
                self._vcov_hat,
                self._dof,
                self._posthoc_estimable(),
            )
        return self._global_cache

    def global_test(
        self, alpha: float | str = "inherit", p_adjust: str = "inherit"
    ) -> pd.DataFrame:
        r"""Perform global test for differential abundance across groups.

        The global test identifies features that are differentially abundant between at
        least two groups across three or more groups.

        .. versionchanged:: 0.7.4
            Fixed a bug in the global test, which would produce inaccurate results.
            Please update the program. The main results are not impacted.

        Parameters
        ----------
        alpha : float or "inherit", optional
            Significance level. Default is "inherit", which will use the value supplied
            upstream.
        p_adjust : str, optional
            Multiple testing correction method. Default is "inherit", which will use
            the *p*-value correction method supplied upstream.

        Returns
        -------
        pd.DataFrame
            Global test result. Columns are:

            - ``FeatureID``: Feature identifier, i.e., dependent variable.

            - ``W``: *W*-statistic quantifying the overall evidence against null
              hypothesis (mean abundance of the feature is the same across all groups).

            - ``pvalue``: *p*-value of the *W*-statistic.

            - ``qvalue``: Corrected *p*-value.

            - ``Signif``: Whether at least one group mean is different from others.

        """
        self._require_groups("global_test")
        alpha, p_adjust = self._stat_params(alpha, p_adjust)
        W, pval, qval, reject = _global_test(
            groups=self._groups,
            beta_hat=self._beta_hat,
            vcov_hat=self._vcov_hat,
            p_adjust=p_adjust,
            alpha=alpha,
            dof=self._dof,
            estimable=self._posthoc_estimable(),
            global_stats=self._get_global_stats(),
        )
        result = pd.DataFrame(
            {"W": W.copy(), "pvalue": pval.copy(), "qvalue": qval, "Signif": reject},
            index=self._features,
            copy=False,
        )
        result.index.name = "FeatureID"
        return result

    def pairwise_test(
        self,
        alpha: float | str = "inherit",
        p_adjust: str = "inherit",
    ) -> pd.DataFrame:
        r"""Perform pairwise directional test between all group pairs.

        Uses mixed directional FDR (mdFDR) correction via bootstrap.

        Parameters
        ----------
        alpha : float or "inherit", optional
            Significance level. Default is "inherit", which will use the value supplied
            upstream.
        p_adjust : str, optional
            Family wise error (FWER) controlling method. Default is "inherit", which
            will use the *p*-value correction method supplied upstream.

        Returns
        -------
        pd.DataFrame
            Pairwise test result with a (FeatureID, Comparison) multi-index. The index
            levels and columns are:

            - ``FeatureID``: Feature identifier, i.e., dependent variable.

            - ``Comparison``: Group contrast being tested.

            - ``Log(FC)``: Estimated difference in group effects on the natural-log
              abundance scale.

            - ``SE``: Standard error of the estimated contrast.

            - ``W``: *W*-statistic, calculated as the estimated contrast divided by its
              standard error.

            - ``pvalue``: Uncorrected *p*-value of the *W*-statistic.

            - ``qvalue``: *p*-value after mixed directional false discovery rate
              correction.

            - ``Signif``: Whether the contrast is significantly different from zero.

        """
        self._require_groups("pairwise_test")
        alpha, p_adjust = self._stat_params(alpha, p_adjust)

        beta, se, W, pval, qval, reject, comparisons = _pairwise_test(
            dmat=self._dmat,
            groups=self._groups,
            beta_hat=self._beta_hat,
            var_hat=self._var_hat,
            vcov_hat=self._vcov_hat,
            dof=self._dof,
            p_adjust=p_adjust,
            alpha=alpha,
            estimable=self._posthoc_estimable(),
            global_stats=self._get_global_stats(),
        )
        index = pd.MultiIndex.from_product(
            (self._features, comparisons), names=("FeatureID", "Comparison")
        )
        columns = {
            "Log(FC)": beta.ravel(),
            "SE": se.ravel(),
            "W": W.ravel(),
            "pvalue": pval.ravel(),
            "qvalue": qval.ravel(),
            "Signif": reject.ravel(),
        }
        result = pd.DataFrame(columns, index=index, copy=False)
        return result

    def dunnett_test(
        self,
        alpha: float | str = "inherit",
        p_adjust: str = "inherit",
        bootstraps: int = 100,
        seed: SeedLike | None = None,
    ) -> pd.DataFrame:
        r"""Perform Dunnett's test (each group vs. reference) with mdFDR.

        Parameters
        ----------
        alpha : float or "inherit", optional
            Significance level. Default is "inherit", which will use the value supplied
            upstream.
        p_adjust : str, optional
            Family wise error (FWER) controlling method. Default is "inherit", which
            will use the *p*-value correction method supplied upstream.
        bootstraps : int, optional
            Number of bootstrap iterations. Default is 100.
        seed : int, Generator, or RandomState, optional
            A user-provided random seed or generator for bootstrap samples. See
            :func:`details <skbio.util.get_rng>`.

        Returns
        -------
        pd.DataFrame
            Dunnett test result with a (FeatureID, Comparison) multi-index. The index
            levels and columns are:

            - ``FeatureID``: Feature identifier, i.e., dependent variable.

            - ``Comparison``: Group-versus-reference contrast being tested.

            - ``Log(FC)``: Estimated group effect relative to the reference group on
              the natural-log abundance scale.

            - ``SE``: Standard error of the estimated contrast.

            - ``W``: *W*-statistic, calculated as the estimated contrast divided by its
              standard error.

            - ``pvalue``: Uncorrected *p*-value of the *W*-statistic.

            - ``qvalue``: *p*-value after mixed directional false discovery rate
              correction.

            - ``Signif``: Whether the group differs significantly from the reference.

        """
        self._require_groups("dunnett_test")
        rng = get_rng(seed)
        alpha, p_adjust = self._stat_params(alpha, p_adjust)

        beta, se, W, pval, qval, reject, comparisons = _dunnett_test(
            dmat=self._dmat,
            groups=self._groups,
            beta_hat=self._beta_hat,
            var_hat=self._var_hat,
            dof=self._dof,
            bootstraps=bootstraps,
            rng=rng,
            p_adjust=p_adjust,
            alpha=alpha,
            estimable=self._posthoc_estimable(),
        )
        index = pd.MultiIndex.from_product(
            (self._features, comparisons), names=("FeatureID", "Comparison")
        )
        columns = {
            "Log(FC)": beta.ravel(),
            "SE": se.ravel(),
            "W": W.ravel(),
            "pvalue": pval.ravel(),
            "qvalue": qval.ravel(),
            "Signif": reject.ravel(),
        }
        result = pd.DataFrame(columns, index=index)
        return result

    def trend_test(
        self,
        alpha: float | str = "inherit",
        p_adjust: str = "inherit",
        trend_contrast: dict | None = None,
        trend_node: dict | None = None,
        bootstraps: int = 100,
        seed: SeedLike | None = None,
    ) -> pd.DataFrame:
        r"""Perform trend test for ordered patterns in group effects.

        Uses constrained optimization to test monotone increasing/decreasing
        patterns in group-level effects.

        Parameters
        ----------
        alpha : float or "inherit", optional
            Significance level. Default is "inherit", which will use the value supplied
            upstream.
        p_adjust : str, optional
            Multiple testing correction method. Default is "inherit", which will use
            the *p*-value correction method supplied upstream.
        trend_contrast, trend_node : dict, optional
            Trend test contrast matrices and their node indices.
        bootstraps : int, optional
            Number of bootstrap iterations. Default is 100.
        seed : int, Generator, or RandomState, optional
            A user-provided random seed or generator for bootstrap samples. See
            :func:`details <skbio.util.get_rng>`.

        Returns
        -------
        pd.DataFrame
            Trend test result indexed by FeatureID. The index and columns are:

            - ``FeatureID``: Feature identifier, i.e., dependent variable.

            - ``W``: Test statistic for the strongest tested trend pattern.

            - ``pvalue``: Bootstrap-estimated *p*-value of the trend statistic.

            - ``qvalue``: *p*-value corrected for multiple testing.

            - ``Signif``: Whether the feature exhibits a significant tested trend.

        Notes
        -----
        The trend test is highly stochastic and requires a large number of bootstraps
        (e.g., 10,000) to stabilize the estimated *p*- and *q*-values. This is because
        every *p*-value is estimated through independent bootstrapping. In comparsion,
        the Dunnett's test (:meth:`dunnett_test`) is more stable.

        """
        self._require_groups("trend_test")
        rng = get_rng(seed)
        alpha, p_adjust = self._stat_params(alpha, p_adjust)

        _, _, W, pval, qval, reject = _trend_test(
            groups=self._groups,
            beta_hat=self._beta_hat,
            var_hat=self._var_hat,
            vcov_hat=self._vcov_hat,
            p_adjust=p_adjust,
            alpha=alpha,
            trend_contrast=trend_contrast,
            trend_node=trend_node,
            bootstraps=bootstraps,
            rng=rng,
            estimable=self._posthoc_estimable(),
        )
        result = pd.DataFrame(
            {"W": W, "pvalue": pval, "qvalue": qval, "Signif": reject},
            index=self._features,  # TODO: Add `copy=False` when safe
        )
        result.index.name = "FeatureID"
        return result


def _group_covmat(vcov_hat, groups):
    """Return a grouping covariance submatrix."""
    k = groups.size
    if vcov_hat.shape[1:] == (k, k):  # full matrix
        return vcov_hat
    return vcov_hat[:, groups][:, :, groups]  # submatrix


def _global_test(
    groups,
    beta_hat,
    vcov_hat,
    alpha=0.05,
    p_adjust="holm",
    dof=None,
    estimable=None,
    global_stats=None,
):
    """Perform ANCOM-BC global test, optionally reusing unadjusted statistics."""
    if global_stats is None:
        global_stats = _global_stats(groups, beta_hat, vcov_hat, dof, estimable)
    W_global, pval = global_stats
    qval = _adjust_pvalues(pval, p_adjust)
    qval = np.where(np.isnan(qval), 1.0, qval)
    reject = qval <= alpha
    return W_global, pval, qval, reject


def _global_stats(groups, beta_hat, vcov_hat, dof=None, estimable=None):
    """Compute global statistics and raw p-values for a fitted model."""
    n_groups = groups.size
    beta_hat_sub = beta_hat[:, groups]
    vcov_hat_sub = _group_covmat(vcov_hat, groups)

    # Keep the previous vectorized path unchanged when all grouping coefficients are
    # estimable. Otherwise, avoid feeding arbitrary pseudoinverse coefficients or
    # covariances into the global quadratic form.
    if estimable is None:
        vcov_hat_sub_inv = np.linalg.pinv(vcov_hat_sub)
        W_global = np.einsum(
            "ni,nij,nj->n", beta_hat_sub, vcov_hat_sub_inv, beta_hat_sub, optimize=True
        )
    else:
        estimable = np.asarray(estimable, dtype=bool)
        W_global = np.full(beta_hat.shape[0], np.nan, dtype=beta_hat.dtype)
        if np.any(estimable):
            beta_valid = beta_hat_sub[estimable]
            vcov_valid_inv = np.linalg.pinv(vcov_hat_sub[estimable])
            W_global[estimable] = np.einsum(
                "ni,nij,nj->n", beta_valid, vcov_valid_inv, beta_valid, optimize=True
            )

    if dof is None:
        p_lower = chi2.cdf(W_global, n_groups)
        p_upper = chi2.sf(W_global, n_groups)
    else:
        p_lower = f.cdf(W_global, n_groups, dof)
        p_upper = f.sf(W_global, n_groups, dof)
    pval = 2 * np.minimum(p_lower, p_upper)
    if estimable is not None:
        pval[~estimable] = 1.0

    return W_global, pval


def _pairwise_test(
    dmat,
    groups,
    beta_hat,
    var_hat,
    vcov_hat,
    dof,
    p_adjust="holm",
    alpha=0.05,
    estimable=None,
    global_stats=None,
):
    """ANCOM-BC2 pairwise directional test.

    For each pair of group levels, compute the difference in coefficients
    and its variance, then apply mdFDR correction.
    """
    covariates = dmat.design_info.column_names
    beta_hat_sub = beta_hat[:, groups]
    group_covars = [covariates[i] for i in groups]
    vcov_group = _group_covmat(vcov_hat, groups)

    # Compute pairwise differences and their variances
    n_tax = beta_hat.shape[0]
    n_group = groups.size

    # Generate all pairwise comparisons
    pair_names = []
    pair_indices = []
    for i, j in combinations(range(n_group), 2):
        pair_names.append(f"{group_covars[j]}_{group_covars[i]}")
        pair_indices.append((j, i))

    # Also include individual group effects
    all_names = list(group_covars) + pair_names
    n_comp = len(all_names)

    beta_pair = np.zeros((n_tax, n_comp))
    var_pair = np.zeros((n_tax, n_comp))

    # Individual effects
    for k in range(n_group):
        beta_pair[:, k] = beta_hat_sub[:, k]
        var_pair[:, k] = var_hat[:, groups[k]]

    # Pairwise differences
    for k, (j, i) in enumerate(pair_indices):
        beta_pair[:, n_group + k] = beta_hat_sub[:, j] - beta_hat_sub[:, i]
        var_pair[:, n_group + k] = (
            vcov_group[:, j, j] + vcov_group[:, i, i] - 2.0 * vcov_group[:, j, i]
        )

    if estimable is not None:
        beta_pair[~estimable] = np.nan
        var_pair[~estimable] = np.nan

    se_pair = np.sqrt(np.maximum(var_pair, 0))
    W_pair = beta_pair / se_pair

    # Apply mdFDR correction
    pval, qval = _mdfdr_pairwise(
        W=W_pair,
        dof=dof,
        fwer_ctrl=p_adjust,
        dmat=dmat,
        groups=groups,
        beta_hat=beta_hat,
        vcov_hat=vcov_group,
        alpha=alpha,
        dof_global=dof,
        estimable=estimable,
        global_stats=global_stats,
    )
    reject = qval <= alpha

    return beta_pair, se_pair, W_pair, pval, qval, reject, all_names


def _mdfdr_pairwise(
    W,
    dof,
    fwer_ctrl,
    dmat,
    groups,
    beta_hat,
    vcov_hat,
    alpha,
    dof_global=None,
    estimable=None,
    global_stats=None,
):
    """Perform mixed directional FDR (mdFDR) correction for pairwise tests.

    1. Run global test to screen significant features (count R).
    2. Only consider R significant features for pairwise p-values.
    3. Adjust at level R * alpha / d.

    """
    n_feats, n_comps = W.shape

    # Calculate p-values
    p_val = _calc_pvalues(W, dof)

    # Screen for significant comparisons using global test
    _, _, _, signif = _global_test(
        groups=groups,
        beta_hat=beta_hat,
        vcov_hat=vcov_hat,
        p_adjust="BH",  # Screening uses BH independently of pairwise correction.
        alpha=alpha,
        dof=dof_global,
        estimable=estimable,
        global_stats=global_stats,
    )
    n_signs = signif.sum().item()  # R

    # Zero out p-values for features not significant in global test
    p_val = p_val * signif[:, None]
    p_val[p_val == 0] = 1.0
    p_val = np.where(np.isnan(p_val), 1.0, p_val)

    # Adjust each feature's comparisons with the family size inflated by
    # the global-screening factor n_feats / n_signs.
    if n_signs:
        n_tests = n_comps * n_feats / n_signs
        q_val = _adjust_pvalues(p_val, fwer_ctrl, axis=1, n_tests=n_tests)
    else:
        q_val = np.ones_like(p_val)

    return p_val, q_val


def _var_diff(vcov_sub):
    """Compute variance of difference for a pair from a covariance sub-matrix.

    For a 2x2 covariance matrix [[var_a, cov_ab], [cov_ab, var_b]],
    var(a - b) = var_a + var_b - 2*cov_ab = trace - 2*off_diag_sum.

    For a general kxk matrix, var(sum of signed differences) =
    sum of all elements with appropriate signs. For the simple pairwise
    case with contrast [1, -1], this is trace - 2*sum(off-diagonal).
    """
    vcov_sub = np.asarray(vcov_sub)
    # For the pairwise case: var(a-b) = var(a) + var(b) - 2*cov(a,b)
    # = sum(diag) - 2*sum(off-diagonal upper/lower)
    # = sum(all elements) - 2*sum(off-diagonal)
    # More precisely: c' V c where c = [1, -1] for 2x2
    if vcov_sub.shape == (2, 2):
        return vcov_sub[0, 0] + vcov_sub[1, 1] - 2 * vcov_sub[0, 1]
    else:
        # General case: for contrast vector c, var = c' V c
        # Default contrast is [1, -1, 0, ...] etc.
        off_diag = vcov_sub.sum() - np.trace(vcov_sub)
        return np.trace(vcov_sub) - off_diag


def _dunnett_test(
    dmat,
    groups,
    beta_hat,
    var_hat,
    dof,
    bootstraps,
    rng,
    p_adjust,
    alpha,
    estimable=None,
):
    """ANCOM-BC2 Dunnett's type of test.

    Compare each group to the reference group with mdFDR correction.
    """
    covariates = dmat.design_info.column_names
    # `groups` is an index array not a slice, so this will guarantee to create copies
    # of data, therefore is safe.
    beta_hat_dunn = beta_hat[:, groups]
    var_hat_dunn = var_hat[:, groups]
    if estimable is not None:
        beta_hat_dunn[~estimable] = np.nan
        var_hat_dunn[~estimable] = np.nan
    se_hat_dunn = np.sqrt(np.maximum(var_hat_dunn, 0))
    W_dunn = beta_hat_dunn / se_hat_dunn

    # mdFDR correction
    pval, qval = _mdfdr_dunnett(
        W=W_dunn,
        dof=dof,
        fwer_ctrl=p_adjust,
        bootstraps=bootstraps,
        rng=rng,
        alpha=alpha,
        estimable=estimable,
    )
    reject = qval <= alpha
    comp_names = [covariates[i] for i in groups]

    return beta_hat_dunn, se_hat_dunn, W_dunn, pval, qval, reject, comp_names


def _mdfdr_dunnett(W, dof, fwer_ctrl, bootstraps, alpha, rng, estimable=None):
    """mdFDR correction for Dunnett's test."""
    n_feats, n_comps = W.shape

    # Step 1: Global test screening via bootstrap
    res_screen = _dunn_global(
        W=W,
        bootstraps=bootstraps,
        dof=dof,
        p_adjust="BH",
        alpha=alpha,
        rng=rng,
        estimable=estimable,
    )
    # TODO: Likewise, should p_adjust be hard-coded as "BH"?
    n_signs = int(res_screen["reject"].sum())
    screen_ind = res_screen["reject"].values

    # Step 2: Compute p-values
    if dof is not None:
        dof = np.asarray(dof)
        p_val = 2 * t.sf(np.abs(W), df=dof if dof.ndim == 0 else dof[:, None])
    else:
        p_val = 2 * norm.sf(np.abs(W))

    # Zero out for non-significant taxa
    p_val = p_val * screen_ind[:, np.newaxis]
    p_val[p_val == 0] = 1.0
    p_val = np.where(np.isnan(p_val), 1.0, p_val)

    # Step 3: Adjust each feature's comparisons using the inflated family size.
    if n_signs:
        n_tests = n_comps * n_feats / n_signs
        q_val = _adjust_pvalues(p_val, fwer_ctrl, axis=1, n_tests=n_tests)
    else:
        q_val = np.ones_like(p_val)

    return p_val, q_val


def _dunn_global(W, bootstraps, dof, p_adjust, alpha, rng, estimable=None):
    """Dunnett's global test for mdFDR.

    Bootstrap-based: generate null W from t-distribution, take max |W|.
    """
    n_tax = W.shape[0]

    # Observed global statistic: max |W| per taxon
    W_global = np.max(np.abs(W), axis=1)

    # Only exceedance counts are needed, not the full bootstrap distribution.
    exceed = np.zeros(n_tax, dtype=np.int64)

    for _ in range(bootstraps):
        # Generate null W from the per-feature t-distribution.
        if dof is not None:
            dof_null = np.nan_to_num(dof, nan=999.0)
            W_null = rng.standard_t(
                dof_null if np.ndim(dof_null) == 0 else dof_null[:, None],
                size=W.shape,
            )
        else:
            W_null = rng.standard_normal(size=W.shape)

        exceed += np.max(np.abs(W_null), axis=1) > W_global

    # P-values from bootstrap
    p_global = exceed / bootstraps
    if estimable is not None:
        p_global[~np.asarray(estimable, dtype=bool)] = 1.0

    # R's p.adjust excludes NA values; ANCOM-BC2 then treats invalid global
    # tests as nonsignificant.
    q_global = _adjust_pvalues(p_global, p_adjust)
    q_global = np.where(np.isnan(q_global), 1.0, q_global)
    reject = q_global <= alpha

    return pd.DataFrame(
        {
            "W": W_global,
            "p_val": p_global,
            "q_val": q_global,
            "reject": reject,
        }
    )


def _trend_test(
    groups,
    beta_hat,
    var_hat,
    vcov_hat,
    p_adjust="holm",
    alpha=0.05,
    trend_contrast=None,
    trend_node=None,
    bootstraps=100,
    rng=None,
    estimable=None,
):
    """ANCOM-BC2 trend test (pattern analysis).

    Uses constrained optimization to test ordered patterns in group effects.
    """
    n_feats = beta_hat.shape[0]
    n_group = groups.size

    beta_hat_sub = beta_hat[:, groups]
    var_hat_sub = var_hat[:, groups]
    vcov_hat_sub = _group_covmat(vcov_hat, groups)

    # Keep the original path when all grouping coefficients are identifiable. If not,
    # compact only the valid rows for the expensive constrained optimization/bootstrap
    # and expand the result afterwards.
    if estimable is None:
        work_idx = None
        beta_work = beta_hat_sub
        var_work = var_hat_sub
        vcov_work = vcov_hat_sub
        n_work = n_feats
    else:
        estimable = np.asarray(estimable, dtype=bool)
        work_idx = np.flatnonzero(estimable)
        beta_work = beta_hat_sub[work_idx]
        var_work = var_hat_sub[work_idx]
        vcov_work = vcov_hat_sub[work_idx]
        n_work = work_idx.size

    if trend_contrast is None:
        increasing = np.eye(n_group)
        increasing[1:, :-1] -= np.eye(n_group - 1)
        trend_contrast = {"increasing": increasing, "decreasing": -increasing}
        trend_node = {name: n_group - 1 for name in trend_contrast}

    n_trend = len(trend_contrast)
    beta_opt_all = np.zeros((n_work, n_group * n_trend))
    l_vals = np.zeros((n_work, n_trend))

    for i in range(n_work):
        for t_idx, (tname, contrast) in enumerate(trend_contrast.items()):
            beta_opt = _constrain_est(beta_work[i], vcov_work[i], np.asarray(contrast))
            start_col = t_idx * n_group
            beta_opt_all[i, start_col : start_col + n_group] = beta_opt
            l_vals[i, t_idx] = _l_infty(beta_opt, trend_node[tname])

    W_work = np.max(l_vals, axis=1)
    opt_idx = np.argmax(l_vals, axis=1)
    beta_trend_work = np.zeros((n_work, n_group))
    for i in range(n_work):
        start_col = opt_idx[i] * n_group
        beta_trend_work[i] = beta_opt_all[i, start_col : start_col + n_group]

    if rng is None:
        rng = np.random.default_rng()
    exceed = np.zeros(n_work, dtype=np.int64)
    var_work_dup = np.nan_to_num(var_work, nan=1.0)
    projections = {
        name: _prep_trend_projection(contrast)
        for name, contrast in trend_contrast.items()
    }

    for _ in range(bootstraps):
        beta_null = rng.standard_normal(size=(n_work, n_group))
        l_null = np.zeros((n_work, n_trend))
        for t_idx, (tname, contrast) in enumerate(trend_contrast.items()):
            beta_null_opt = _constrain_est_identity(
                beta_null, contrast, projections[tname]
            )
            beta_null_opt *= np.sqrt(np.maximum(var_work_dup, 0))
            node = trend_node[tname]
            l_null[:, t_idx] = np.maximum(
                np.abs(beta_null_opt[:, node]),
                np.abs(beta_null_opt[:, node] - beta_null_opt[:, -1]),
            )
        exceed += np.max(l_null, axis=1) > W_work

    p_work = exceed / bootstraps
    if work_idx is None:
        W_trend = W_work
        beta_hat_trend = beta_trend_work
        pval = p_work
    else:
        W_trend = np.full(n_feats, np.nan, dtype=beta_hat.dtype)
        W_trend[work_idx] = W_work
        beta_hat_trend = np.full((n_feats, n_group), np.nan, dtype=beta_hat.dtype)
        beta_hat_trend[work_idx] = beta_trend_work
        pval = np.ones(n_feats, dtype=beta_hat.dtype)
        pval[work_idx] = p_work

    qval = _adjust_pvalues(pval, p_adjust)
    qval = np.where(np.isnan(qval), 1.0, qval)
    reject = qval <= alpha

    se = np.sqrt(np.maximum(var_hat_sub, 0))
    if estimable is not None:
        se[~estimable] = np.nan

    return beta_hat_trend, se, W_trend, pval, qval, reject


def _constrain_est(beta_hat, vcov_hat, contrast):
    """Constrained estimation via quadratic programming.

    Minimize (beta - beta_opt)' P (beta - beta_opt) subject to
    contrast @ beta_opt >= 0 (each row of contrast defines one inequality).

    Uses scipy.optimize.minimize with SLSQP method, replacing R's quadprog::solve.QP.

    """
    P = _safe_inverse_spd(vcov_hat)
    n = len(beta_hat)
    contrast = np.asarray(contrast)

    # Objective: 0.5 * x' D x - d' x  (quadratic form)
    Dmat = 2 * P
    Dmat = (Dmat + Dmat.T) / 2
    # Add small ridge for numerical stability (matches R code: diag(Dmat) += 1e-10)
    Dmat += 1e-10 * np.eye(n)
    dvec = 2 * P @ beta_hat

    def objective(x):
        return 0.5 * x @ Dmat @ x - dvec @ x

    def grad(x):
        return Dmat @ x - dvec

    # Each row of contrast defines one inequality: contrast[i] @ x >= 0
    # SLSQP expects a single constraint function returning a vector
    n_constraints = contrast.shape[0]
    constraints = {
        "type": "ineq",
        "fun": lambda x: contrast @ x,  # Returns vector; each element must be >= 0
        "jac": lambda x: contrast,
    }

    try:
        result = minimize(
            objective,
            x0=beta_hat,
            jac=grad,
            method="SLSQP",
            constraints=constraints,
            options={"ftol": 1e-12, "maxiter": 1000},
        )
        return result.x
    except Exception:
        return np.zeros(n)


def _prep_trend_projection(contrast):
    """Prepare active constraints and inverse Gram matrices for trend bootstraps.

    Keep the two matrix products separate when applying these operators to preserve
    the numerical behavior of the original projection. Large constraint systems use
    SLSQP instead of enumerating exponentially many active sets.
    """
    contrast = np.asarray(contrast)
    n_constraints = contrast.shape[0]
    if n_constraints > 10:
        return None

    projections = [(None, None)]  # No active constraints.
    for size in range(1, n_constraints + 1):
        for active in combinations(range(n_constraints), size):
            active_contrast = contrast[list(active)]
            gram = active_contrast @ active_contrast.T
            projections.append((active_contrast, np.linalg.pinv(gram)))
    return tuple(projections)


def _constrain_est_identity(beta_hat, contrast, projections=None):
    """Project coefficient vectors onto linear inequalities under identity covariance.

    This is the identity-covariance specialization of :func:`_constrain_est` used by
    the trend bootstrap. It enumerates active constraint sets and evaluates all
    feature vectors simultaneously, avoiding repeated SLSQP calls. Pass operators
    from :func:`_prep_trend_projection` to reuse them across bootstrap draws.
    """
    beta_hat = np.asarray(beta_hat)
    contrast = np.asarray(contrast)
    n_features, n_coefficients = beta_hat.shape
    n_constraints = contrast.shape[0]

    # Active-set enumeration is efficient for the small ordinal contrasts used
    # by trend tests, but grows exponentially for larger custom systems.
    if n_constraints > 10:
        identity = np.eye(n_coefficients)
        return np.array([_constrain_est(beta, identity, contrast) for beta in beta_hat])

    if projections is None:
        projections = _prep_trend_projection(contrast)

    candidates = []
    valid = []

    for active_contrast, gram_inv in projections:
        if active_contrast is not None:
            multipliers = -(beta_hat @ active_contrast.T @ gram_inv)
            candidate = beta_hat + multipliers @ active_contrast
            active_valid = np.all(multipliers >= -1e-10, axis=1)
        else:
            candidate = beta_hat
            active_valid = np.ones(n_features, dtype=bool)

        candidates.append(candidate)
        valid.append(active_valid & np.all(contrast @ candidate.T >= -1e-10, axis=0))

    candidates = np.asarray(candidates)
    valid = np.asarray(valid)
    distances = np.sum((candidates - beta_hat) ** 2, axis=2)
    distances[~valid] = np.inf
    selected = np.argmin(distances, axis=0)
    return candidates[selected, np.arange(n_features)]


def _safe_inverse_spd(A, ridge=1e-8):
    """Safe inverse of a symmetric positive-definite matrix."""
    A = (A + A.T) / 2
    try:
        L = np.linalg.cholesky(A)
        return np.linalg.solve(A, np.eye(A.shape[0]))
    except np.linalg.LinAlgError:
        return np.linalg.inv(A + ridge * np.eye(A.shape[0]))


def _l_infty(beta_opt, node):
    """Compute l_infinity norm for a pattern at specified node.

    Matches R's .l_infty function:
    l = max(abs(beta_opt[node]), abs(beta_opt[node] - beta_opt[length(beta_opt)]))

    Note: node is 0-based in Python (1-based in R). The last element
    beta_opt[-1] corresponds to beta_opt[length(beta_opt)] in R.
    """
    beta_opt = np.asarray(beta_opt)
    return max(
        abs(beta_opt[node]),
        abs(beta_opt[node] - beta_opt[-1]),
    )


def struc_zero(table, metadata, grouping, neg_lb=False):
    r"""Identify features with structural zeros.

    .. versionadded:: 0.7.1

    Structural zeros refer to features that are systematically absent from certain
    sample groups. Consequently, the observed feature frequencies are all zeros, or
    mostly zeros, due to variability in technical factors. This function tests
    whether the proportion of observed zeros is close to zero, which suggests the
    absence of a feature in a given sample group.

    Parameters
    ----------
    table : table_like of shape (n_samples, n_features)
        A matrix containing count or proportional abundance data of the samples.
    metadata : pd.DataFrame or 2-D array_like
        Metadata of the samples. Rows correspond to samples and columns correspond
        to covariates (attributes). Must be a pandas DataFrame or convertible to a
        pandas DataFrame.
    grouping : str
        A metadata column name indicating the assignment of samples to groups.
    neg_lb : bool, optional
        Determine whether to use negative lower bound when calculating sample
        proportions. Default is False. Generally, it is recommended to set it as True
        when the sample size per group is relatively large.

    Returns
    -------
    pd.DataFrame of bool of shape (n_features, n_groups)
        A table indicating whether each feature (row) is a structural zero in each
        group (column) (True: structural zero, False: not structural zero).

    Notes
    -----
    The structural zero test was initially proposed and implemented in the ANCOM-II
    method [1]_. It was adopted to the ANCOM-BC method [2]_ as a recommended method to
    complement test results. See :func:`ancombc` for how to use this function along
    with the ANCOM-BC test. Nevertheless, this function is generally useful with or
    without explicit statistical tests of feature abundances.

    A feature found to be a structural zero in a group should be automatically
    considered as differentially (less) abundant compared with other groups in which
    this feature is not a structural zero. Meanwhile, this feature should be excluded
    from subsequent analyses that involves this group. If a feature is identified as a
    structural zero in all groups, this feature should be removed entirely from
    downstream analyses.

    Note that the structural zero test should be applied to the original table before
    adding a pseudocount, which will otherwise mask all zeros and invalidate this test.

    References
    ----------
    .. [1] Kaul, A., Mandal, S., Davidov, O., & Peddada, S. D. (2017). Analysis of
       microbiome data in the presence of excess zeros. Frontiers in Microbiology, 8,
       2114.

    .. [2] Lin, H. and Peddada, S.D., 2020. Analysis of compositions of microbiomes
       with bias correction. Nature Communications, 11(1), p.3514.

    Examples
    --------
    >>> from skbio.stats.composition import struc_zero
    >>> import pandas as pd

    Generate a DataFrame with 10 samples and 6 features with 0's in specific groups:

    >>> table = pd.DataFrame([[ 7,  1,  0, 11,  3,  1],
    ...                       [ 1,  1,  0, 13, 13,  0],
    ...                       [11,  5,  0,  1,  4,  1],
    ...                       [ 2,  2,  0, 16,  4,  0],
    ...                       [ 0,  1,  0,  0,  6,  0],
    ...                       [14,  8,  7,  9,  0,  5],
    ...                       [ 0,  7,  4,  1,  0, 26],
    ...                       [ 8,  1,  4, 28,  0, 10],
    ...                       [ 2,  2,  2,  4,  0,  5],
    ...                       [ 6,  4, 10,  1,  0,  9]],
    ...                      index=[f's{i}' for i in range(10)],
    ...                      columns=[f'f{i}' for i in range(6)])

    Then create a grouping vector. In this example, there is a treatment group
    and a placebo group.

    >>> metadata = pd.DataFrame(
    ...     {'grouping': ['treatment'] * 5 + ['placebo'] * 5},
    ...     index=[f's{i}' for i in range(10)])

    The ``struc_zero`` function will identify features with structural zeros. Features
    that are identified as structural zeros in given groups should not be used in
    further analyses such as ``ancombc`` and  ``dirmult_ttest``.

    Setting ``neg_lb=True`` declares that the true prevalence of a feature in a group
    is not significantly different from zero.

    >>> result = struc_zero(table, metadata, grouping='grouping', neg_lb=True)
    >>> result
        placebo  treatment
    f0    False      False
    f1    False      False
    f2    False       True
    f3    False      False
    f4     True      False
    f5    False       True

    """
    # Validate feature table and metadata
    matrix, samples, features = _ingest_table(table)
    metadata = _check_metadata(metadata, matrix, samples)

    unique_groups, group_indices, group_counts = np.unique(
        metadata[grouping], return_inverse=True, return_counts=True
    )

    # Create a boolean matrix to indicate whether the value in table is 0 or not
    tmp = np.nan_to_num(matrix) != 0

    n_groups = len(unique_groups)
    n_features = tmp.shape[1]

    # Initialize group sum matrix
    group_sums = np.zeros((n_groups, n_features))
    np.add.at(group_sums, group_indices, tmp.astype(int))

    # Calculate sample sizes of the groups for each feature
    sample_size = group_counts[:, np.newaxis]

    # Calculate sample proportions of the groups for each feature
    p_hat = group_sums / sample_size

    # Calculate the lower bound of a 95% confidence interval for sample proportion
    if neg_lb:
        p_hat = p_hat - 1.96 * (p_hat * (1 - p_hat) / sample_size) ** 0.5

    zero_idx = p_hat <= 0

    # Output structural zero as a DataFrame
    return pd.DataFrame(zero_idx.T, index=features, columns=unique_groups)
